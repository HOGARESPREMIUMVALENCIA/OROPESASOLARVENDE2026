// Calle Vinaroz 4 · datos del proyecto (recreación orientativa). Generado por gen_config.py
window.EDIFICIO = {
 "nombre": "Calle Vinaroz 4",
 "titulo": "Calle <em>Vinaroz 4</em>",
 "antetitulo": "Oropesa del Mar · Solar en venta · 350.000 €",
 "texto": "El edificio que se puede levantar aquí, ya terminado: 32 viviendas nórdicas con terraza, un centro de salud en planta baja y 40 plazas de garaje. Pulsa cualquier planta para entrar.",
 "cifras": [
  [
   32,
   "Viviendas"
  ],
  [
   593,
   "m² locales"
  ],
  [
   40,
   "Plazas garaje"
  ],
  [
   350,
   "Precio solar",
   ".000 €"
  ]
 ],
 "pie": "Recreación orientativa · proyecto, imágenes, distribución y precios de venta no vinculantes · datos de mercado oct. 2026",
 "contacto": {
  "nombre": "Rafael Clausi Estellés",
  "agencia": "Hogares Premium Valencia",
  "tel": "685 856 148",
  "wa": "34685856148",
  "email": "hogarespremium@gmail.com",
  "web": "www.hogarespremiumvalencia.com",
  "registro": "API 00767 · RAICV 1915"
 },
 "solar": {
  "ref": "6124621BE5462C0001ZF",
  "calif": "Suelo urbano no consolidado · ZU-P4 Ensanche Colectivo Abierto",
  "catastral": 2494,
  "neto": 1218,
  "cesion": 1276,
  "ocupacion": 75,
  "altura": "16 m · PB + 4",
  "techoViv": 3972,
  "techoLoc": 593,
  "garaje": 1218,
  "tasacion": 382000,
  "precio": 350000
 },
 "plantas": [
  {
   "bloque": 1,
   "planta": 0,
   "nombre": "Planta baja",
   "tipo": "L1",
   "puertas": [
    {
     "p": "Local 1 · Atención primaria",
     "precio": 296000,
     "m2": 296,
     "estado": "ok",
     "nota": "Interés manifestado por un centro de salud"
    }
   ]
  },
  {
   "bloque": 1,
   "planta": 1,
   "nombre": "Planta 1",
   "tipo": "V",
   "puertas": [
    {
     "p": "Puerta A · 3 dorm.",
     "precio": 274500,
     "m2": 103.6,
     "c": 139.4,
     "estado": "ok"
    },
    {
     "p": "Puerta B · 3 dorm.",
     "precio": 274500,
     "m2": 103.6,
     "c": 139.4,
     "estado": "ok"
    },
    {
     "p": "Puerta C · 2 dorm.",
     "precio": 214000,
     "m2": 80.7,
     "c": 108.6,
     "estado": "ok"
    },
    {
     "p": "Puerta D · 2 dorm.",
     "precio": 214000,
     "m2": 80.7,
     "c": 108.6,
     "estado": "ok"
    }
   ]
  },
  {
   "bloque": 1,
   "planta": 2,
   "nombre": "Planta 2",
   "tipo": "V",
   "puertas": [
    {
     "p": "Puerta A · 3 dorm.",
     "precio": 277500,
     "m2": 103.6,
     "c": 139.4,
     "estado": "ok"
    },
    {
     "p": "Puerta B · 3 dorm.",
     "precio": 277500,
     "m2": 103.6,
     "c": 139.4,
     "estado": "ok"
    },
    {
     "p": "Puerta C · 2 dorm.",
     "precio": 216000,
     "m2": 80.7,
     "c": 108.6,
     "estado": "ok"
    },
    {
     "p": "Puerta D · 2 dorm.",
     "precio": 216000,
     "m2": 80.7,
     "c": 108.6,
     "estado": "ok"
    }
   ]
  },
  {
   "bloque": 1,
   "planta": 3,
   "nombre": "Planta 3",
   "tipo": "V",
   "puertas": [
    {
     "p": "Puerta A · 3 dorm.",
     "precio": 280000,
     "m2": 103.6,
     "c": 139.4,
     "estado": "ok"
    },
    {
     "p": "Puerta B · 3 dorm.",
     "precio": 280000,
     "m2": 103.6,
     "c": 139.4,
     "estado": "ok"
    },
    {
     "p": "Puerta C · 2 dorm.",
     "precio": 218500,
     "m2": 80.7,
     "c": 108.6,
     "estado": "ok"
    },
    {
     "p": "Puerta D · 2 dorm.",
     "precio": 218500,
     "m2": 80.7,
     "c": 108.6,
     "estado": "ok"
    }
   ]
  },
  {
   "bloque": 1,
   "planta": 4,
   "nombre": "Planta 4",
   "tipo": "V",
   "puertas": [
    {
     "p": "Puerta A · 3 dorm.",
     "precio": 283000,
     "m2": 103.6,
     "c": 139.4,
     "estado": "ok"
    },
    {
     "p": "Puerta B · 3 dorm.",
     "precio": 283000,
     "m2": 103.6,
     "c": 139.4,
     "estado": "ok"
    },
    {
     "p": "Puerta C · 2 dorm.",
     "precio": 220500,
     "m2": 80.7,
     "c": 108.6,
     "estado": "ok"
    },
    {
     "p": "Puerta D · 2 dorm.",
     "precio": 220500,
     "m2": 80.7,
     "c": 108.6,
     "estado": "ok"
    }
   ]
  },
  {
   "bloque": 2,
   "planta": 0,
   "nombre": "Planta baja",
   "tipo": "L2",
   "puertas": [
    {
     "p": "Local 2 · Especialidades",
     "precio": 297000,
     "m2": 297,
     "estado": "ok",
     "nota": "Interés manifestado por un centro de salud"
    }
   ]
  },
  {
   "bloque": 2,
   "planta": 1,
   "nombre": "Planta 1",
   "tipo": "V",
   "puertas": [
    {
     "p": "Puerta A · 3 dorm.",
     "precio": 274500,
     "m2": 103.6,
     "c": 139.4,
     "estado": "ok"
    },
    {
     "p": "Puerta B · 3 dorm.",
     "precio": 274500,
     "m2": 103.6,
     "c": 139.4,
     "estado": "ok"
    },
    {
     "p": "Puerta C · 2 dorm.",
     "precio": 214000,
     "m2": 80.7,
     "c": 108.6,
     "estado": "ok"
    },
    {
     "p": "Puerta D · 2 dorm.",
     "precio": 214000,
     "m2": 80.7,
     "c": 108.6,
     "estado": "ok"
    }
   ]
  },
  {
   "bloque": 2,
   "planta": 2,
   "nombre": "Planta 2",
   "tipo": "V",
   "puertas": [
    {
     "p": "Puerta A · 3 dorm.",
     "precio": 277500,
     "m2": 103.6,
     "c": 139.4,
     "estado": "ok"
    },
    {
     "p": "Puerta B · 3 dorm.",
     "precio": 277500,
     "m2": 103.6,
     "c": 139.4,
     "estado": "ok"
    },
    {
     "p": "Puerta C · 2 dorm.",
     "precio": 216000,
     "m2": 80.7,
     "c": 108.6,
     "estado": "ok"
    },
    {
     "p": "Puerta D · 2 dorm.",
     "precio": 216000,
     "m2": 80.7,
     "c": 108.6,
     "estado": "ok"
    }
   ]
  },
  {
   "bloque": 2,
   "planta": 3,
   "nombre": "Planta 3",
   "tipo": "V",
   "puertas": [
    {
     "p": "Puerta A · 3 dorm.",
     "precio": 280000,
     "m2": 103.6,
     "c": 139.4,
     "estado": "ok"
    },
    {
     "p": "Puerta B · 3 dorm.",
     "precio": 280000,
     "m2": 103.6,
     "c": 139.4,
     "estado": "ok"
    },
    {
     "p": "Puerta C · 2 dorm.",
     "precio": 218500,
     "m2": 80.7,
     "c": 108.6,
     "estado": "ok"
    },
    {
     "p": "Puerta D · 2 dorm.",
     "precio": 218500,
     "m2": 80.7,
     "c": 108.6,
     "estado": "ok"
    }
   ]
  },
  {
   "bloque": 2,
   "planta": 4,
   "nombre": "Planta 4",
   "tipo": "V",
   "puertas": [
    {
     "p": "Puerta A · 3 dorm.",
     "precio": 283000,
     "m2": 103.6,
     "c": 139.4,
     "estado": "ok"
    },
    {
     "p": "Puerta B · 3 dorm.",
     "precio": 283000,
     "m2": 103.6,
     "c": 139.4,
     "estado": "ok"
    },
    {
     "p": "Puerta C · 2 dorm.",
     "precio": 220500,
     "m2": 80.7,
     "c": 108.6,
     "estado": "ok"
    },
    {
     "p": "Puerta D · 2 dorm.",
     "precio": 220500,
     "m2": 80.7,
     "c": 108.6,
     "estado": "ok"
    }
   ]
  }
 ],
 "construidos": {
  "B": 139.4,
  "A": 108.6
 },
 "mercado": {
  "medio": {
   "valor": 2149,
   "fecha": "2026-10",
   "variacion_12m": "+6,9%",
   "centro": 1528,
   "centro_variacion_12m": "+10,3%",
   "fuente": "https://www.fotocasa.es/es/indice-precio-vivienda/oropesa-del-mar-orpesa/todas-las-zonas"
  },
  "testigos": [
   {
    "zona": "Marena, C/ Los Naranjos 14 (Playa de la Concha), garaje incluido",
    "m2": 100,
    "dorm": 2,
    "precio": 243500,
    "eur_m2": 2435,
    "obra_nueva": true,
    "fuente": "https://www.idealista.com/inmueble/112774330/"
   },
   {
    "zona": "Marena, Playa de la Concha, garaje incluido",
    "m2": 104,
    "dorm": 2,
    "precio": 217000,
    "eur_m2": 2087,
    "obra_nueva": true,
    "fuente": "https://www.idealista.com/inmueble/112581459/"
   },
   {
    "zona": "Marena, Playa de la Concha, garaje incluido",
    "m2": 107,
    "dorm": 2,
    "precio": 240000,
    "eur_m2": 2243,
    "obra_nueva": true,
    "fuente": "https://www.idealista.com/inmueble/112768902/"
   },
   {
    "zona": "Marena, Playa de la Concha, garaje incluido",
    "m2": 128,
    "dorm": 2,
    "precio": 255500,
    "eur_m2": 1996,
    "obra_nueva": true,
    "fuente": "https://www.idealista.com/inmueble/112581527/"
   },
   {
    "zona": "Marena, Playa de la Concha, garaje incluido",
    "m2": 133,
    "dorm": 3,
    "precio": 290000,
    "eur_m2": 2180,
    "obra_nueva": true,
    "fuente": "https://www.idealista.com/inmueble/111190363/"
   },
   {
    "zona": "Marena, Playa de la Concha, ático, garaje incluido",
    "m2": 167,
    "dorm": 2,
    "precio": 343000,
    "eur_m2": 2054,
    "obra_nueva": true,
    "fuente": "https://www.idealista.com/inmueble/111877842/"
   },
   {
    "zona": "Edificio Ciudad Jardín II, C/ Torre la Sal (precio desde + IVA)",
    "m2": 96,
    "dorm": 3,
    "precio": 197000,
    "eur_m2": 2052,
    "obra_nueva": true,
    "fuente": "https://housage.es/obra-nueva-castellon/oropesa-del-mar/edificio-ciudad-jarden-2/"
   }
  ],
  "locales": [
   {
    "zona": "C/ Dr. Clarà 13 (Centro)",
    "m2": 243,
    "precio": 199000,
    "eur_m2": 819,
    "fuente": "https://english.habitaclia.com/buy/business-premise/calle-dr-clara-13/centro/oropesa-del-mar-orpesa/7246b6c6-2b3e-4022-b263-8a54ab6dfe0a/d"
   },
   {
    "zona": "C/ Velázquez 57 (Centro)",
    "m2": 118,
    "precio": 85000,
    "eur_m2": 720,
    "fuente": "https://english.habitaclia.com/buy/business-premise/calle-de-velazquez-57/centro/oropesa-del-mar-orpesa/98f737ff-6eea-47c4-bdcc-9e2448be3f47/d"
   },
   {
    "zona": "Centro",
    "m2": 160,
    "precio": 120000,
    "eur_m2": 750,
    "fuente": "https://english.habitaclia.com/buy/business-premise/centro/oropesa-del-mar-orpesa/96ce1aff-7254-40bd-b784-8b07a580d7bd/d"
   },
   {
    "zona": "Av. de la Estación 37 (Centro)",
    "m2": 98,
    "precio": 105000,
    "eur_m2": 1071,
    "fuente": "https://english.habitaclia.com/buy/business-premise/avenida-de-la-estacion-37/centro/oropesa-del-mar-orpesa/4d4b0003-24c1-44e7-a9d1-29020946b072/d"
   }
  ],
  "garajes": [
   {
    "zona": "C/ Torreblanca 12 (Centro)",
    "precio": 5000,
    "fuente": "https://english.habitaclia.com/buy/parking/calle-torreblanca-12/centro/oropesa-del-mar-orpesa/9a17813d-3d2a-43f2-82d5-2750fcabe653/d"
   },
   {
    "zona": "Zona Centro (edificio de 2005)",
    "precio": 15000,
    "fuente": "https://es.wallapop.com/item/garaje-en-venta-en-zona-centro-en-oropesa-del-mar-orpesa-1288980273"
   },
   {
    "zona": "C/ Pamplona 13 (Morro de Gos)",
    "precio": 9500,
    "fuente": "https://english.habitaclia.com/buy/parking/calle-pamplona-13/playa-morro-de-gos/oropesa-del-mar-orpesa/9bb51a09-a627-4ccd-b19f-242bde617892/d"
   },
   {
    "zona": "C/ Lucena 20 (Morro de Gos)",
    "precio": 11000,
    "fuente": "https://english.habitaclia.com/buy/parking/calle-lucena-20/playa-morro-de-gos/oropesa-del-mar-orpesa/bff71908-9810-46d1-87da-274c66e587cc/d"
   },
   {
    "zona": "Av. de Valencia 58 (Morro de Gos)",
    "precio": 11900,
    "fuente": "https://english.habitaclia.com/buy/parking/avenida-de-valencia-58/playa-morro-de-gos/oropesa-del-mar-orpesa/40f95e18-0f6c-44d6-a398-f06bea3e9591/d"
   }
  ],
  "demanda": [
   {
    "dato": "Población de 12.640 habitantes a 1-1-2025",
    "fuente": "https://en.wikipedia.org/wiki/Oropesa_del_Mar"
   },
   {
    "dato": "Población: 8.830 (2018) -> 11.785 (2024), +33 % en 6 años (padrón del INE)",
    "fuente": "https://www.foro-ciudad.com/castellon/oropesa-del-mar---orpesa/habitantes.html"
   },
   {
    "dato": "36,36 % nacidos en el extranjero (2022); 17,2 % mayores de 65 años (2024)",
    "fuente": "https://www.foro-ciudad.com/castellon/oropesa-del-mar---orpesa/habitantes.html"
   },
   {
    "dato": "1.311 compraventas de vivienda en 2025, líder de la costa de Castellón; 26,75 % de compradores extranjeros (Notariado)",
    "fuente": "https://castellonplaza.com/castellonplaza/plaza-inmobiliaria609/la-compraventa-de-vivienda-por-municipios-oropesa-burriana-y-moncofa-lideran-las-operaciones-en-la-costa-de-castellon"
   },
   {
    "dato": "Vivienda turística: 10.116 plazas en 2025 (+2,1 %); único destino de la provincia que creció (HOSBEC)",
    "fuente": "https://actualidadcastellon.com/castellon-estable-vivienda-turistica-oropesa-crece/"
   },
   {
    "dato": "Centro de salud saturado; el Ayuntamiento pidió ampliarlo y calcular las ratios con la población real (oct-2023)",
    "fuente": "https://www.castelloninformacion.com/oropesa-sanidad-centro-salud/"
   },
   {
    "dato": "Pleno del 30-01-2026: cesión de parcela en C/ Severo Ochoa 9 (7.149 m² de suelo, 4.827 m² de techo) para el nuevo centro de salud público; sin presupuesto ni plazos publicados",
    "fuente": "https://www.elperiodic.com/orpesa/ubicacion-confirmada-para-nuevo-centro-salud-oropesa_1057738"
   }
  ]
 },
 "obra": [
  {
   "f": "Compra del solar",
   "a": 0,
   "b": 1,
   "t": "Arras y escritura con la documentación registral al día"
  },
  {
   "f": "Proyecto de urbanización y reparcelación",
   "a": 1,
   "b": 7,
   "t": "Cesión de viales y zona verde (1.276 m²)"
  },
  {
   "f": "Proyecto básico y de ejecución",
   "a": 1,
   "b": 8,
   "t": "En paralelo a la tramitación urbanística"
  },
  {
   "f": "Licencia de obras",
   "a": 6,
   "b": 12,
   "t": "Plazo municipal estimado, a confirmar con el Ayuntamiento"
  },
  {
   "f": "Venta sobre plano",
   "a": 8,
   "b": 32,
   "t": "Comercialización desde la licencia"
  },
  {
   "f": "Urbanización",
   "a": 9,
   "b": 13,
   "t": "Viales, aceras, servicios y zona verde"
  },
  {
   "f": "Excavación, cimentación y sótano",
   "a": 12,
   "b": 15,
   "t": "40 plazas · 1.218 m²"
  },
  {
   "f": "Estructura",
   "a": 15,
   "b": 21,
   "t": "Una planta al mes aprox."
  },
  {
   "f": "Fachadas y cubierta",
   "a": 18,
   "b": 27,
   "t": "Estuco blanco, lamas de roble, placas solares"
  },
  {
   "f": "Instalaciones y acabados",
   "a": 22,
   "b": 30,
   "t": "Aerotermia, carpinterías, cocinas equipadas"
  },
  {
   "f": "Final de obra y entrega",
   "a": 30,
   "b": 32,
   "t": "Licencia de primera ocupación y escrituras"
  }
 ]
};
