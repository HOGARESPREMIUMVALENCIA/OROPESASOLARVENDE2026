/* Calle Vinaroz 4 · Oropesa del Mar — el edificio terminado en 3D, en su calle, con sol de verano.
   API: EXT.montar(el) · .hora(h) · .vista(nombre) · .obra(mes|null) · .sotano(bool) · .activar(bool) · .foto(w,h) → dataURL
   Eventos: EXT.onHover(info|null) · EXT.onClick(info)  info = { bloque: 1|2, planta: 0..4 }
   Ejes: x a lo largo de la calle · +z hacia la calle (fachada principal) · y arriba. Metros. Orientación ilustrativa. */
(function () {
  const BW = 25.4, BD = 18, GAP = 6, PB = 3.6, FH = 3.0, NP = 4;
  const X1 = -BW - GAP / 2, X2 = GAP / 2;          // origen (u=0) de cada bloque
  const TOP = PB + NP * FH;                         // 15,6 m (cumbrera de forjado) + peto → 16,4 m
  let host, W = 1, H = 1, activo = true, rafPend = false;

  const renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputEncoding = THREE.sRGBEncoding; renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = .55;
  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0xcfe0ec, 350, 1800);
  const cam = new THREE.PerspectiveCamera(34, 1, .5, 6000);
  const ctr = new THREE.OrbitControls(cam, renderer.domElement);
  ctr.enableDamping = true; ctr.dampingFactor = .06; ctr.maxPolarAngle = Math.PI * .495; ctr.minDistance = 8; ctr.maxDistance = 420;
  ctr.target.set(0, 7, -6); cam.position.set(-48, 20, 58); ctr.autoRotateSpeed = .35;

  // ---------- Cielo y luz ----------
  const sky = new THREE.Sky(); sky.scale.setScalar(4500); scene.add(sky);
  const su = sky.material.uniforms; su.turbidity.value = 2.2; su.rayleigh.value = 1.6; su.mieCoefficient.value = .004; su.mieDirectionalG.value = .82;
  const hemi = new THREE.HemisphereLight(0xb8d4f0, 0x8a7458, .5); scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xfff1dc, 3.2); sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048); Object.assign(sun.shadow.camera, { left: -80, right: 80, top: 80, bottom: -80, near: 10, far: 600 });
  sun.shadow.bias = -.0003; sun.shadow.normalBias = .04; scene.add(sun); scene.add(sun.target);
  const pmrem = new THREE.PMREMGenerator(renderer); let envRT = null;

  // ---------- Texturas procedurales ----------
  const lienzo = (w, h, draw) => { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h); return c; };
  const tx = (c, rx = 1, ry = 1) => { const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rx, ry); t.encoding = THREE.sRGBEncoding; t.anisotropy = 8; return t; };
  const rnd = (a, b) => a + Math.random() * (b - a);
  const ruido = (base, amp, n = 256) => lienzo(n, n, (g) => { const d = g.createImageData(n, n); for (let i = 0; i < d.data.length; i += 4) { const v = base + (Math.random() - .5) * amp; d.data[i] = v; d.data[i + 1] = v * .99; d.data[i + 2] = v * .97; d.data[i + 3] = 255; } g.putImageData(d, 0, 0); });
  const T_ESTUCO = tx(ruido(246, 10), 6, 6);
  const T_PIEDRA = tx(lienzo(512, 512, (g, w, h) => { g.fillStyle = '#d9cfbf'; g.fillRect(0, 0, w, h); for (let y = 0; y < 8; y++) for (let x = 0; x < 4; x++) { g.fillStyle = `hsl(36,${rnd(14, 22)}%,${rnd(74, 82)}%)`; g.fillRect(x * 128 + (y % 2) * 64 + 2, y * 64 + 2, 124, 60); } }), 4, 2);
  const T_ASFALTO = tx(lienzo(512, 512, (g, w, h) => { g.fillStyle = '#5d5f62'; g.fillRect(0, 0, w, h); for (let i = 0; i < 9000; i++) { g.fillStyle = `rgba(${rnd(30, 120)},${rnd(30, 120)},${rnd(30, 120)},.25)`; g.fillRect(rnd(0, w), rnd(0, h), 2, 2); } }), 24, 3);
  const T_ACERA = tx(lienzo(256, 256, (g, w, h) => { g.fillStyle = '#9a8f88'; g.fillRect(0, 0, w, h); for (let y = 0; y < 8; y++) for (let x = 0; x < 4; x++) { g.fillStyle = `hsl(12,${rnd(18, 26)}%,${rnd(58, 66)}%)`; g.fillRect(x * 64 + (y % 2) * 32 + 1, y * 32 + 1, 62, 30); } }), 40, 2);
  const T_CESPED = tx(lienzo(256, 256, (g, w, h) => { g.fillStyle = '#7f9a52'; g.fillRect(0, 0, w, h); for (let i = 0; i < 6000; i++) { g.fillStyle = `hsla(${rnd(70, 95)},${rnd(25, 45)}%,${rnd(32, 52)}%,.5)`; g.fillRect(rnd(0, w), rnd(0, h), 1.5, rnd(2, 5)); } }), 30, 30);
  const T_SECO = tx(lienzo(256, 256, (g, w, h) => { g.fillStyle = '#8f8a5c'; g.fillRect(0, 0, w, h); for (let i = 0; i < 6000; i++) { g.fillStyle = `hsla(${rnd(45, 90)},${rnd(20, 45)}%,${rnd(30, 55)}%,.55)`; g.fillRect(rnd(0, w), rnd(0, h), 1.5, rnd(2, 6)); } }), 12, 4);
  const T_TIERRA = tx(ruido(120, 40), 10, 10);
  const T_SOLAR = tx(lienzo(128, 128, (g, w, h) => { g.fillStyle = '#1b2a44'; g.fillRect(0, 0, w, h); g.strokeStyle = '#9fb4cf'; g.lineWidth = 1.2; for (let i = 0; i <= 6; i++) { g.beginPath(); g.moveTo(i * w / 6, 0); g.lineTo(i * w / 6, h); g.stroke(); } for (let i = 0; i <= 10; i++) { g.beginPath(); g.moveTo(0, i * h / 10); g.lineTo(w, i * h / 10); g.stroke(); } }));

  function rotulo(texto, opt = {}) {
    const c = lienzo(opt.w || 1024, opt.h || 128, (g, w, h) => {
      g.fillStyle = opt.fondo || 'rgba(0,0,0,0)'; g.fillRect(0, 0, w, h);
      g.font = `${opt.peso || 600} ${opt.px || 70}px ${opt.fuente || 'Inter, Arial, sans-serif'}`; g.fillStyle = opt.color || '#1F3A5F';
      g.textAlign = 'center'; g.textBaseline = 'middle'; if (opt.track) g.letterSpacing = opt.track;
      g.fillText(texto, w / 2, h / 2 + 2);
    });
    const t = tx(c); return new THREE.MeshStandardMaterial({ map: t, transparent: true, roughness: .5, metalness: .1 });
  }

  // nubes altas de verano (pocas y finas)
  {
    const c = lienzo(256, 128, (g, w, h) => { for (let i = 0; i < 70; i++) { const x = rnd(30, w - 30), y = rnd(40, h - 30), r = rnd(12, 34); const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, 'rgba(255,255,255,.55)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill(); } });
    const t = new THREE.CanvasTexture(c);
    for (let k = 0; k < 14; k++) { const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true, opacity: rnd(.45, .8), depthWrite: false, fog: false })); const a = rnd(0, 6.28), r = rnd(700, 1500); sp.position.set(Math.cos(a) * r, rnd(260, 420), Math.sin(a) * r); sp.scale.set(rnd(380, 620), rnd(110, 170), 1); scene.add(sp); }
  }
  // ---------- Materiales ----------
  const M = o => new THREE.MeshStandardMaterial(o);
  const MAT = {
    estuco: M({ map: T_ESTUCO, color: 0xf3efe7, roughness: .92 }),
    estucoOscuro: M({ color: 0xd9d3c8, roughness: .9 }),
    piedra: M({ map: T_PIEDRA, roughness: .75 }),
    forjado: M({ color: 0xf7f6f2, roughness: .8 }),
    madera: M({ color: 0xa8743f, roughness: .55 }),
    carpinteria: M({ color: 0x2f3337, roughness: .45, metalness: .5 }),
    vidrio: new THREE.MeshPhysicalMaterial({ color: 0x4f6577, roughness: .03, metalness: .35, reflectivity: .9, envMapIntensity: .9, emissive: 0xffb466, emissiveIntensity: 0 }),
    barandilla: new THREE.MeshPhysicalMaterial({ color: 0xcfe6ee, roughness: .02, transparent: true, opacity: .32, envMapIntensity: 1.2, depthWrite: false }),
    hormigon: M({ color: 0xa9a7a2, roughness: .95 }),
    asfalto: M({ map: T_ASFALTO, roughness: .95 }),
    acera: M({ map: T_ACERA, roughness: .9 }),
    bordillo: M({ color: 0xc9c4bb, roughness: .8 }),
    cesped: M({ map: T_CESPED, roughness: 1 }),
    seco: M({ map: T_SECO, roughness: 1 }),
    tierra: M({ map: T_TIERRA, color: 0xa07a58, roughness: 1 }),
    hoja: M({ color: 0x5d7a3a, roughness: .85 }), hoja2: M({ color: 0x7f9a55, roughness: .85 }), olivo: M({ color: 0x8fa07a, roughness: .9 }),
    tronco: M({ color: 0x6b5442, roughness: .95 }),
    solar: M({ map: T_SOLAR, roughness: .25, metalness: .4 }),
    alu: M({ color: 0xbfc4c8, metalness: .8, roughness: .35 }),
    grua: M({ color: 0xf2b705, roughness: .6 }),
    valla: M({ color: 0xe8e8e8, roughness: .7 }),
    mar: new THREE.MeshPhysicalMaterial({ color: 0x2c7fa8, roughness: .12, metalness: .1, envMapIntensity: 1 }),
    agua: new THREE.MeshPhysicalMaterial({ color: 0x46b4c8, roughness: .05, envMapIntensity: 1 }),
    textil: M({ color: 0xece4d4, roughness: 1 }), cojin: M({ color: 0x9aab94, roughness: 1 }), mostaza: M({ color: 0xd6a84a, roughness: 1 }),
    maceta: M({ color: 0xdcd5c9, roughness: .8 }),
    farola: M({ color: 0x3a3d40, roughness: .5, metalness: .6 }),
  };
  MAT.acera.userData.m = 2.4; MAT.asfalto.userData.m = 16; MAT.cesped.userData.m = 8; MAT.seco.userData.m = 8; MAT.piedra.userData.m = 3.2; MAT.estuco.userData.m = 4;
  function texInterior(k) {
    return lienzo(256, 256, (g, w, h) => {
      const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#6f8597'); gr.addColorStop(.35, '#34414d'); gr.addColorStop(1, '#232a31'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
      g.fillStyle = 'rgba(255,240,215,.10)'; g.fillRect(w * .25, h * .55, w * .5, h * .45);
      if (k === 0) { [[0, .22], [.8, .2]].forEach(([x, an]) => { for (let i = 0; i < 9; i++) { g.fillStyle = `rgba(${236 - i % 2 * 14},${228 - i % 2 * 14},${214 - i % 2 * 14},.92)`; g.fillRect((x + i * an / 9) * w, 0, an / 9 * w + 1, h); } }); }
      if (k === 1) { for (let y = 0; y < h * .45; y += 6) { g.fillStyle = 'rgba(225,220,208,.9)'; g.fillRect(0, y, w, 4); } }
      if (k === 2) { g.fillStyle = 'rgba(240,233,220,.55)'; g.fillRect(0, 0, w, h); for (let i = 0; i < 12; i++) { g.fillStyle = 'rgba(200,190,175,.25)'; g.fillRect(i * w / 12, 0, 3, h); } }
      if (k === 3) { g.fillStyle = 'rgba(255,214,150,.55)'; g.beginPath(); g.ellipse(w * .5, h * .12, w * .18, h * .05, 0, 0, 7); g.fill(); g.fillStyle = 'rgba(120,90,60,.5)'; g.fillRect(w * .2, h * .62, w * .35, h * .2); }
      const rf = g.createLinearGradient(0, 0, w, h); rf.addColorStop(0, 'rgba(255,255,255,.18)'); rf.addColorStop(.4, 'rgba(255,255,255,0)'); rf.addColorStop(.6, 'rgba(255,255,255,.07)'); rf.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = rf; g.fillRect(0, 0, w, h);
    });
  }
  const VIDRIOS = [0, 1, 2, 3].map(k => { const t = tx(texInterior(k)); return new THREE.MeshPhysicalMaterial({ map: t, emissiveMap: t, emissive: 0xffb466, emissiveIntensity: 0, metalness: .25, roughness: .04, envMapIntensity: .75 }); });
  VIDRIOS.forEach(m => m.userData.m = 0);
  let vk = 0; const vidrio = () => VIDRIOS[(vk++ * 7 + (vk >> 2)) % 4];

  // ---------- Utilidades de geometría ----------
  // superficies con textura a escala real (metros por repetición en userData.m)
  const CACHE = new Map();
  function escalar(mat, w, d) {
    if (!mat.map || !mat.userData.m) return mat;
    const k = mat.uuid + w + 'x' + d; if (CACHE.has(k)) return CACHE.get(k);
    const c = mat.clone(); c.userData = {}; c.map = mat.map.clone(); c.map.needsUpdate = true; c.map.repeat.set(w / mat.userData.m, d / mat.userData.m);
    CACHE.set(k, c); return c;
  }
  function caja(gr, w, h, d, x, y, z, mat, sombra = true) {
    mat = escalar(mat, w, d);
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); m.position.set(x, y + h / 2, z);
    m.castShadow = sombra; m.receiveShadow = true; gr.add(m); return m;
  }
  const cil = (gr, rt, rb, h, x, y, z, mat, s = 16) => { const m = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, s), mat); m.position.set(x, y + h / 2, z); m.castShadow = m.receiveShadow = true; gr.add(m); return m; };

  // ---------- Entorno ----------
  const entorno = new THREE.Group(); scene.add(entorno);
  const suelo = new THREE.Mesh(new THREE.PlaneGeometry(3000, 3000), M({ color: 0xbdb39a, roughness: 1 })); suelo.rotation.x = -Math.PI / 2; suelo.position.y = -.05; suelo.receiveShadow = true; entorno.add(suelo);
  // calle Vinaroz: acera 3,5 m · calzada 8 m · acera 3,5 m
  const CALLE_Z = 3.5, CALZ = 8;
  caja(entorno, 400, .1, CALZ, 0, -.05, CALLE_Z + CALZ / 2, MAT.asfalto, false);
  caja(entorno, 400, .16, 3.5, 0, -.05, CALLE_Z / 2, MAT.acera, false);
  caja(entorno, 400, .16, 3.5, 0, -.05, CALLE_Z + CALZ + 1.75, MAT.acera, false);
  caja(entorno, 400, .18, .25, 0, -.05, CALLE_Z - .1, MAT.bordillo, false); caja(entorno, 400, .18, .25, 0, -.05, CALLE_Z + CALZ + .1, MAT.bordillo, false);
  // marcas viales y paso de cebra
  const blanco = M({ color: 0xf2f2f2, roughness: .6 });
  for (let x = -190; x < 190; x += 6) caja(entorno, 3, .02, .15, x, .02, CALLE_Z + CALZ / 2, blanco, false);
  for (let k = 0; k < 7; k++) caja(entorno, .5, .02, CALZ - .6, -40 + k * 1.0, .02, CALLE_Z + CALZ / 2, blanco, false);
  const rCalle = new THREE.Mesh(new THREE.PlaneGeometry(14, 1.75), rotulo('C/ VINARÒS · CALLE VINAROZ', { color: '#f4f1ea', px: 64, w: 1024, h: 128 }));
  rCalle.rotation.x = -Math.PI / 2; rCalle.position.set(14, .04, CALLE_Z + CALZ * .72); rCalle.material.opacity = .55; entorno.add(rCalle);

  // calle lateral a cada lado del conjunto
  [-36, 36].forEach(x => { caja(entorno, 8, .1, 140, x, -.06, -55, MAT.asfalto, false); caja(entorno, 2.5, .14, 140, x - Math.sign(x) * 5.2, -.05, -55, MAT.acera, false); });

  // edificios vecinos con ritmo y colores de la zona (ocres, crema, ladrillo)
  const PAL = ['#e2b45c', '#ecd7a6', '#f1e8d6', '#d9a066', '#c98a5a', '#efe3c9', '#e7c98a'];
  function fachadaTex(color, pisos, huecos) {
    return lienzo(512, 64 * pisos, (g, w, h) => {
      g.fillStyle = color; g.fillRect(0, 0, w, h);
      for (let p = 0; p < pisos; p++) {
        const y = p * 64;
        g.fillStyle = 'rgba(0,0,0,.08)'; g.fillRect(0, y + 58, w, 4);
        if (p === pisos - 1) { g.fillStyle = '#b9b2a6'; g.fillRect(0, y + 8, w, 56); continue; }
        for (let k = 0; k < huecos; k++) {
          const x = (k + .5) * w / huecos - 22;
          g.fillStyle = '#2d3640'; g.fillRect(x, y + 14, 44, 38);
          g.fillStyle = 'rgba(255,255,255,.18)'; g.fillRect(x + 3, y + 16, 18, 34);
          g.fillStyle = 'rgba(40,40,40,.55)'; g.fillRect(x - 6, y + 38, 56, 3); g.fillRect(x - 6, y + 50, 56, 2);
          for (let b = 0; b < 8; b++) g.fillRect(x - 4 + b * 7, y + 38, 1.5, 14);
        }
      }
      g.fillStyle = '#8c8070'; g.fillRect(0, h - 64, w, 64);
      for (let k = 0; k < huecos; k++) { g.fillStyle = k % 3 ? '#4b4f52' : '#6c5a46'; g.fillRect((k + .5) * w / huecos - 26, h - 56, 52, 50); }
    });
  }
  function vecino(x, z, w, d, pisos, color, rotY = 0, balcones = true) {
    const g = new THREE.Group(); const h = pisos * 3 + .6;
    const t = tx(fachadaTex(color, pisos + 1, Math.max(2, Math.round(w / 4)))), tl = tx(fachadaTex(color, pisos + 1, Math.max(2, Math.round(d / 4))));
    const mf = M({ map: t, roughness: .9 }), ml = M({ map: tl, roughness: .9 }), mt = M({ color: 0xb9b2a6, roughness: .9 });
    const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), [ml, ml, mt, mt, mf, mf]); b.position.y = h / 2; b.castShadow = b.receiveShadow = true; g.add(b);
    if (balcones) for (let p = 1; p < pisos; p++) caja(g, w * .92, .18, .9, 0, p * 3 + .02, d / 2 + .45, M({ color: 0xe9e1d2, roughness: .8 }));
    g.position.set(x, 0, z); g.rotation.y = rotY; entorno.add(g); return g;
  }
  // lado de nuestra acera
  vecino(-55, -9, 26, 16, 5, PAL[0]);
  vecino(56, -9, 28, 16, 6, PAL[1]);
  // acera de enfrente (mirando al edificio)
  [[-80, 22, 5, 2], [-54, 24, 6, 0], [54, 24, 6, 3], [80, 24, 5, 4]].forEach(([x, w, p, c]) => vecino(x, CALLE_Z + CALZ + 3.5 + 9, w, 16, p, PAL[c], Math.PI));
  // plaza ajardinada frente al solar (deja ver la fachada desde la acera de enfrente)
  caja(entorno, 76, .14, 30, 0, -.05, CALLE_Z + CALZ + 3.5 + 15, MAT.acera, false);
  caja(entorno, 30, .2, 12, -14, -.04, CALLE_Z + CALZ + 3.5 + 16, MAT.cesped, false); caja(entorno, 22, .2, 12, 20, -.04, CALLE_Z + CALZ + 3.5 + 16, MAT.cesped, false);
  [[-26, 22], [-12, 24], [2, 21], [14, 25], [28, 22]].forEach(([x, dz], i) => arbol(x, CALLE_Z + CALZ + dz, 1, i % 2 ? 'palmera' : 'olivo'));
  [-6, 8].forEach(x => caja(entorno, 2, .45, .5, x, 0, CALLE_Z + CALZ + 6.5, MAT.madera));
  [[-40, 2], [40, 3]].forEach(([x, p], i) => vecino(x, CALLE_Z + CALZ + 3.5 + 70, 22, 14, p, PAL[(i + 4) % PAL.length], Math.PI));
  // fondo (tras la zona verde)
  [[-50, 5], [-20, 6], [12, 5], [42, 6]].forEach(([x, p], i) => vecino(x, -60, 26, 16, p, PAL[(i + 3) % PAL.length]));
  // tejido urbano lejano (instanciado)
  {
    const geo = new THREE.BoxGeometry(1, 1, 1); geo.translate(0, .5, 0);
    const mats = PAL.map(c => M({ color: new THREE.Color(c).multiplyScalar(.96), roughness: .95 }));
    mats.forEach((mat, mi) => {
      const n = 46, im = new THREE.InstancedMesh(geo, mat, n); const o = new THREE.Object3D(); let k = 0;
      for (let i = 0; i < n * 3 && k < n; i++) {
        const a = Math.random() * Math.PI * 2, r = rnd(120, 330), x = Math.cos(a) * r, z = Math.sin(a) * r * .8 - 30;
        if (x > 222 || (Math.abs(x) < 120 && z > -100 && z < 95)) continue;
        o.position.set(x, 0, z); o.scale.set(rnd(14, 30), rnd(6, 22), rnd(12, 22)); o.rotation.y = Math.round(Math.random()) * Math.PI / 2; o.updateMatrix(); im.setMatrixAt(k++, o.matrix);
      }
      im.count = k; im.castShadow = false; im.receiveShadow = true; entorno.add(im);
    });
  }
  // mar al este y montañas al oeste (Desert de les Palmes)
  const mar = new THREE.Mesh(new THREE.PlaneGeometry(3000, 4000), MAT.mar); mar.rotation.x = -Math.PI / 2; mar.position.set(1750, .02, 0); entorno.add(mar);
  const arena = new THREE.Mesh(new THREE.PlaneGeometry(36, 4000), M({ color: 0xe6d3a8, roughness: 1 })); arena.rotation.x = -Math.PI / 2; arena.position.set(238, .03, 0); entorno.add(arena);
  {
    const g = new THREE.PlaneGeometry(600, 2600, 30, 130); const p = g.attributes.position;
    for (let i = 0; i < p.count; i++) { const x = p.getX(i), y = p.getY(i); const r = Math.max(0, (300 - x) / 600); const h = Math.pow(r, 1.4) * (150 + 80 * Math.sin(y * .004) + 55 * Math.sin(y * .011 + 1) + 22 * Math.sin(y * .033)); p.setZ(i, h + (Math.random() - .5) * 4); }
    g.computeVertexNormals();
    const mon = new THREE.Mesh(g, M({ color: 0x75855a, roughness: 1, flatShading: true })); mon.rotation.x = -Math.PI / 2; mon.position.set(-760, -2, -100); entorno.add(mon);
  }

  // árboles, palmeras, coches y farolas
  // ---------- Vegetación realista: hojas dibujadas una a una sobre tarjetas con transparencia ----------
  function texHojas(tipo) {
    texHojas.c = texHojas.c || {}; if (texHojas.c[tipo]) return texHojas.c[tipo];
    const c = lienzo(512, 512, (g, w, h) => {
      g.clearRect(0, 0, w, h);
      const hoja = (x, y, L, A, ang, col) => {
        g.save(); g.translate(x, y); g.rotate(ang);
        const gr = g.createLinearGradient(-A, 0, A, 0); gr.addColorStop(0, col[0]); gr.addColorStop(1, col[1]); g.fillStyle = gr;
        g.beginPath(); g.moveTo(0, -L / 2); g.quadraticCurveTo(A, -L * .1, 0, L / 2); g.quadraticCurveTo(-A, -L * .1, 0, -L / 2); g.fill();
        g.strokeStyle = 'rgba(30,45,20,.35)'; g.lineWidth = Math.max(.6, A * .08); g.beginPath(); g.moveTo(0, -L / 2); g.lineTo(0, L / 2); g.stroke(); g.restore();
      };
      const ramitas = n => { g.strokeStyle = 'rgba(70,52,38,.8)'; for (let k = 0; k < n; k++) { g.lineWidth = rnd(1, 3); g.beginPath(); const a = rnd(0, 6.28); g.moveTo(256, 256); g.quadraticCurveTo(256 + Math.cos(a) * 90, 256 + Math.sin(a) * 60, 256 + Math.cos(a + .3) * rnd(150, 220), 256 + Math.sin(a + .3) * rnd(150, 220)); g.stroke(); } };
      if (tipo === 'olivo') {
        ramitas(10);
        for (let k = 0; k < 760; k++) { const r = 220 * Math.pow(Math.random(), .6), a = rnd(0, 6.28); const v = Math.random();
          hoja(256 + Math.cos(a) * r, 256 + Math.sin(a) * r, rnd(26, 38), rnd(5, 8), rnd(0, 6.28), v < .25 ? ['#a9b39a', '#86936f'] : ['#5f7148', '#45552f']); }
      } else if (tipo === 'arbusto') {
        for (let k = 0; k < 520; k++) { const r = 230 * Math.pow(Math.random(), .5), a = rnd(0, 6.28); hoja(256 + Math.cos(a) * r, 256 + Math.sin(a) * r, rnd(14, 22), rnd(6, 9), rnd(0, 6.28), Math.random() < .5 ? ['#5f8a3c', '#3f6328'] : ['#7aa04b', '#4f7430']); }
      } else {
        ramitas(14);
        for (let k = 0; k < 300; k++) { const r = 225 * Math.pow(Math.random(), .55), a = rnd(0, 6.28); const v = Math.random();
          hoja(256 + Math.cos(a) * r, 256 + Math.sin(a) * r, rnd(30, 46), rnd(13, 19), rnd(0, 6.28), v < .25 ? ['#9bbf5a', '#6d9440'] : v < .7 ? ['#5f8f3a', '#41692a'] : ['#466e2c', '#2f4f1f']); }
      }
    });
    const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.anisotropy = 8;
    const m = new THREE.MeshStandardMaterial({ map: t, alphaTest: .45, side: THREE.DoubleSide, roughness: .75, envMapIntensity: .3 });
    const d = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map: t, alphaTest: .45 });
    return (texHojas.c[tipo] = { m, d });
  }
  function texPalma() {
    if (texPalma.c) return texPalma.c;
    const c = lienzo(128, 512, (g, w, h) => {
      g.clearRect(0, 0, w, h);
      for (let y = 8; y < h - 4; y += 7) { const t = y / h, L = 58 * Math.sin(Math.PI * Math.min(1, t * 1.15)) + 6;
        [-1, 1].forEach(sd => { g.strokeStyle = `hsl(${88 - t * 18},${42 + t * 10}%,${30 + Math.random() * 10}%)`; g.lineWidth = 3.2; g.beginPath(); g.moveTo(64, y); g.quadraticCurveTo(64 + sd * L * .5, y - 4, 64 + sd * L, y + 10); g.stroke(); }); }
      g.strokeStyle = '#7a8a46'; g.lineWidth = 5; g.beginPath(); g.moveTo(64, 0); g.lineTo(64, h); g.stroke();
    });
    const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.anisotropy = 8;
    return (texPalma.c = { m: new THREE.MeshStandardMaterial({ map: t, alphaTest: .4, side: THREE.DoubleSide, roughness: .7, envMapIntensity: .3 }), d: new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map: t, alphaTest: .4 }) });
  }
  function corteza(clara) {
    corteza.c = corteza.c || {}; const k = clara ? 'c' : 'o'; if (corteza.c[k]) return corteza.c[k];
    const c = lienzo(128, 256, (g, w, h) => { g.fillStyle = clara ? '#8d8574' : '#5a4636'; g.fillRect(0, 0, w, h);
      for (let i = 0; i < 260; i++) { g.fillStyle = `rgba(${clara ? '60,55,45' : '30,20,12'},${rnd(.1, .35)})`; g.fillRect(rnd(0, w), rnd(0, h), rnd(2, 6), rnd(10, 40)); }
      if (clara) for (let i = 0; i < 40; i++) { g.fillStyle = `rgba(200,195,170,${rnd(.15, .35)})`; g.beginPath(); g.ellipse(rnd(0, w), rnd(0, h), rnd(6, 16), rnd(8, 20), 0, 0, 7); g.fill(); } });
    const t = tx(c, 1, 2); return (corteza.c[k] = M({ map: t, roughness: .95 }));
  }
  function copa(g, tipo, centro, rx, ry, n, tam) {
    const H = texHojas(tipo), im = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1), H.m, n);
    im.customDepthMaterial = H.d; im.castShadow = true; im.receiveShadow = true;
    const col = new THREE.Color(), _o = new THREE.Object3D(), _v = new THREE.Vector3();
    for (let k = 0; k < n; k++) {
      const u = rnd(0, 6.28), v = Math.acos(rnd(-1, 1)), r = Math.pow(Math.random(), .35);
      _o.position.set(centro.x + Math.sin(v) * Math.cos(u) * rx * r, centro.y + Math.cos(v) * ry * r, centro.z + Math.sin(v) * Math.sin(u) * rx * r);
      _v.copy(_o.position).sub(centro).multiplyScalar(2).add(_o.position); _o.lookAt(_v);
      _o.rotateZ(rnd(0, 6.28)); _o.rotateX(rnd(-.7, .7)); const sc = rnd(tam * .75, tam * 1.25); _o.scale.set(sc, sc, sc); _o.updateMatrix(); im.setMatrixAt(k, _o.matrix);
      const luz = .78 + .3 * (Math.cos(v) * .5 + .5) + rnd(-.06, .06); im.setColorAt(k, col.setRGB(luz, luz, luz * .97));
    }
    g.add(im); return im;
  }
  function rama(g, mat, a, b, r0, r1) {
    const d = new THREE.Vector3().subVectors(b, a), L = d.length();
    const m = new THREE.Mesh(new THREE.CylinderGeometry(r1, r0, L, 9), mat); m.position.copy(a).add(b).multiplyScalar(.5);
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize()); m.castShadow = m.receiveShadow = true; g.add(m); return m;
  }
  function arbol(x, z, s = 1, tipo = 'redondo') {
    const g = new THREE.Group(); g.position.set(x, 0, z); g.scale.setScalar(s); g.rotation.y = rnd(0, 6.28); entorno.add(g);
    if (tipo === 'palmera') {
      const T = palmTronco(), n = 12, alto = rnd(8.5, 10.5); let p = new THREE.Vector3(0, 0, 0); const curva = rnd(.04, .09);
      for (let k = 0; k < n; k++) { const q = new THREE.Vector3(Math.sin(k * .18) * k * curva * 3, (k + 1) * alto / n, 0); rama(g, T, p, q, .3 - k * .009, .29 - (k + 1) * .009); p = q; }
      const P = texPalma(), top = p.clone();
      for (let k = 0; k < 20; k++) {
        const geo = new THREE.PlaneGeometry(1.1, 4.4, 1, 12); geo.translate(0, 2.2, 0);
        const pos = geo.attributes.position; for (let i = 0; i < pos.count; i++) { const t = pos.getY(i) / 4.4; pos.setZ(i, t * t * 2.3); pos.setX(i, pos.getX(i) * (1 - t * .3)); }
        geo.computeVertexNormals();
        const f = new THREE.Mesh(geo, P.m); f.customDepthMaterial = P.d; f.castShadow = true; f.receiveShadow = true;
        f.position.copy(top); f.rotation.order = 'YXZ'; f.rotation.y = k / 20 * Math.PI * 2 + rnd(-.15, .15); f.rotation.x = (k % 4 === 0 ? rnd(.5, .85) : rnd(1.0, 1.55)) + (k > 16 ? .6 : 0);
        if (k > 16) f.material = P.m.clone(), f.material.color.setRGB(.75, .62, .38);
        g.add(f);
      }
      for (let k = 0; k < 9; k++) { const d = new THREE.Mesh(new THREE.SphereGeometry(.09, 6, 5), M({ color: 0xc27a2c, roughness: .6 })); d.position.set(top.x + rnd(-.3, .3), top.y - rnd(.2, .7), top.z + rnd(-.3, .3)); g.add(d); }
      return g;
    }
    if (tipo === 'olivo') {
      const T = corteza(true);
      const a = new THREE.Vector3(0, 0, 0), b = new THREE.Vector3(rnd(-.3, .3), 1.3, rnd(-.3, .3));
      rama(g, T, a, b, .28, .2);
      for (let k = 0; k < 4; k++) { const ang = k / 4 * 6.28 + rnd(-.3, .3); rama(g, T, b, new THREE.Vector3(Math.cos(ang) * rnd(.9, 1.4), rnd(2.2, 2.7), Math.sin(ang) * rnd(.9, 1.4)), .14, .07); }
      copa(g, 'olivo', new THREE.Vector3(0, 3.0, 0), 2.2, 1.3, 520, 1.25);
      return g;
    }
    // árbol de sombra de calle (plátano / morera)
    const T = corteza(false), h = rnd(2.6, 3.2);
    const a = new THREE.Vector3(0, 0, 0), b = new THREE.Vector3(rnd(-.15, .15), h, rnd(-.15, .15)); rama(g, T, a, b, .2, .15);
    const fines = [];
    for (let k = 0; k < 6; k++) { const ang = k / 6 * 6.28 + rnd(-.3, .3), e = new THREE.Vector3(Math.cos(ang) * rnd(1.2, 1.9), h + rnd(1.0, 2.0), Math.sin(ang) * rnd(1.2, 1.9)); rama(g, T, b, e, .1, .05); fines.push(e); }
    copa(g, 'platano', new THREE.Vector3(0, h + 1.7, 0), 2.5, 1.8, 330, 1.25);
    fines.forEach(e => copa(g, 'platano', e, .9, .7, 30, 1.0));
    return g;
  }
  function palmTronco() {
    if (palmTronco.c) return palmTronco.c;
    const c = lienzo(128, 256, (g, w, h) => { g.fillStyle = '#8a7356'; g.fillRect(0, 0, w, h); for (let y = 0; y < h; y += 16) { g.fillStyle = 'rgba(50,35,22,.55)'; g.fillRect(0, y, w, 4); g.fillStyle = 'rgba(190,170,130,.35)'; g.fillRect(0, y + 5, w, 3); for (let i = 0; i < 10; i++) { g.fillStyle = 'rgba(40,28,18,.25)'; g.fillRect(rnd(0, w), y + rnd(0, 14), rnd(4, 14), 2); } } });
    return (palmTronco.c = M({ map: tx(c, 2, 4), roughness: .95 }));
  }
  // arbustos bajos para jardineras y alcorques
  function arbusto(gr, x, y, z, r) { const g = new THREE.Group(); g.position.set(x, y, z); gr.add(g); copa(g, 'arbusto', new THREE.Vector3(0, r * .7, 0), r, r * .7, Math.round(90 * r * r + 30), .5); return g; }
  for (let x = -110; x <= 110; x += 11) { if (Math.abs(x) < 5) continue; arbol(x + rnd(-1, 1), CALLE_Z - .9, rnd(.8, 1.0), Math.abs(x) % 22 < 11 ? 'redondo' : 'olivo'); arbol(x + 5 + rnd(-1, 1), CALLE_Z + CALZ + .9, rnd(.8, 1.0)); }
  const COCHES = [0xf2f2f2, 0x2b2f35, 0x9aa3ad, 0x6b2c2c, 0x30475e, 0xc7c2b6, 0x1f3a5f];
  function coche(x, z, rot, c) {
    const g = new THREE.Group(); g.position.set(x, 0, z); g.rotation.y = rot; entorno.add(g);
    const RB = THREE.RoundedBoxGeometry, pint = new THREE.MeshPhysicalMaterial({ color: c, metalness: .55, roughness: .22, clearcoat: 1, clearcoatRoughness: .08 });
    const cristal = new THREE.MeshPhysicalMaterial({ color: 0x1a222b, metalness: .6, roughness: .05, envMapIntensity: 1.2 });
    const add = (geo, mat, px, py, pz) => { const m = new THREE.Mesh(geo, mat); m.position.set(px, py, pz); m.castShadow = m.receiveShadow = true; g.add(m); return m; };
    add(RB ? new RB(1.82, .62, 4.35, 4, .18) : new THREE.BoxGeometry(1.82, .62, 4.35), pint, 0, .62, 0);
    const cab = add(RB ? new RB(1.6, .58, 2.25, 4, .22) : new THREE.BoxGeometry(1.6, .58, 2.25), cristal, 0, 1.12, -.25); cab.scale.set(1, 1, 1);
    add(new THREE.BoxGeometry(1.5, .06, 1.9), pint, 0, 1.42, -.25);
    [[-.84, 1.38], [.84, 1.38], [-.84, -1.42], [.84, -1.42]].forEach(([a, b]) => { const r = add(new THREE.CylinderGeometry(.33, .33, .22, 20), M({ color: 0x121212, roughness: .85 }), a, .33, b); r.rotation.z = Math.PI / 2; const l = add(new THREE.CylinderGeometry(.2, .2, .23, 16), M({ color: 0xb9bcbf, metalness: .9, roughness: .3 }), a * 1.01, .33, b); l.rotation.z = Math.PI / 2; });
    [-.62, .62].forEach(a => { add(new THREE.BoxGeometry(.38, .1, .04), M({ color: 0xf6f3e8, emissive: 0x333333 }), a, .72, 2.17); add(new THREE.BoxGeometry(.38, .1, .04), M({ color: 0x8e1515, roughness: .3 }), a, .74, -2.17); });
    return g;
  }
  for (let x = -100; x < 100; x += 6.5) { if (x > -33 && x < 33 && Math.random() < .55) continue; if (Math.random() < .35) continue; coche(x, CALLE_Z + 1.2, Math.PI / 2, COCHES[Math.floor(Math.random() * COCHES.length)]); }
  for (let x = -96; x < 100; x += 6.5) { if (Math.random() < .4) continue; coche(x, CALLE_Z + CALZ - 1.2, -Math.PI / 2, COCHES[Math.floor(Math.random() * COCHES.length)]); }
  for (let x = -100; x <= 100; x += 22) { const g = new THREE.Group(); g.position.set(x + 8, 0, CALLE_Z - .5); entorno.add(g); cil(g, .07, .1, 5.5, 0, 0, 0, MAT.farola, 8); caja(g, .3, .12, 1.2, 0, 5.4, .45, MAT.farola); }

  // zona verde de cesión tras el solar (parque nuevo) y estado actual (antes de obra)
  const zonaVerde = new THREE.Group(); scene.add(zonaVerde);
  caja(zonaVerde, 62.8, .12, 18, 0, -.05, -BD - 9 - 1.4, MAT.cesped, false);
  caja(zonaVerde, 2.2, .14, 17, -8, -.04, -BD - 9 - 1.4, MAT.acera, false); caja(zonaVerde, 50, .14, 2.2, 0, -.04, -BD - 4, MAT.acera, false);
  [[-24, -30], [-14, -36], [6, -31], [18, -37], [27, -29], [-2, -38]].forEach(([x, z], i) => { const a = arbol(x, z, rnd(.9, 1.2), i % 3 === 0 ? 'palmera' : 'olivo'); zonaVerde.add(a); });
  [[-18, -26], [10, -26]].forEach(([x, z]) => { caja(zonaVerde, 2, .45, .5, x, 0, z, MAT.madera); });
  const solarActual = new THREE.Group(); scene.add(solarActual);  // el solar hoy (fase 0 del 4D)
  caja(solarActual, 62.8, .14, 19.4 + 18, 0, -.04, -(19.4 + 18) / 2 + .4, MAT.seco, false);
  [[-20, -8], [8, -12], [22, -5]].forEach(([x, z]) => solarActual.add(arbol(x, z, .8, 'olivo')));
  for (let x = -31; x <= 31; x += 2.5) caja(solarActual, .05, 1.1, .05, x, 0, .2, MAT.tronco);
  caja(solarActual, 62.8, .04, .04, 0, 1.0, .2, MAT.tronco); solarActual.visible = false;
  caja(scene, 62.8, .1, 19.4, 0, -.06, -BD / 2 + .2, M({ color: 0xd8d0c2, roughness: .95 }), false); // urbanización del solar (patio)

  // ---------- El edificio ----------
  const edificio = new THREE.Group(); scene.add(edificio);
  const PLANTAS = [];                 // [bloque][planta] → { estructura, envolvente }
  const hit = new THREE.Group(); scene.add(hit);
  const glow = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshBasicMaterial({ color: 0xc8a96a, transparent: true, opacity: .28, depthWrite: false }));
  const glowE = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(1, 1, 1)), new THREE.LineBasicMaterial({ color: 0xf2dca8 }));
  glow.add(glowE); glow.visible = false; scene.add(glow);

  // instanciado de lamas de madera
  const lamasM = []; const lamaGeo = new THREE.BoxGeometry(.06, 1, .12);
  function lamas(x0, x1, y0, h, z) { for (let x = x0; x <= x1; x += .16) lamasM.push([x, y0 + h / 2, z, h]); }

  function bloque(nb, X0) {
    const B = []; PLANTAS[nb] = B;
    const g = new THREE.Group(); edificio.add(g);
    const wx = u => X0 + u, wz = v => -BD + v;
    // ---- Planta baja (centro de salud + portal + rampa/instalaciones) ----
    {
      const est = new THREE.Group(), env = new THREE.Group(); g.add(est, env); B[0] = { est, env, y0: 0, h: PB };
      caja(est, BW, .35, BD, wx(BW / 2), PB - .35, wz(BD / 2), MAT.hormigon);
      for (let i = 0; i <= 5; i++) for (let j = 0; j <= 3; j++) caja(est, .4, PB - .35, .4, wx(.4 + i * (BW - .8) / 5), 0, wz(.4 + j * (BD - .8) / 3), MAT.hormigon);
      // fachada principal: piedra + vidrio
      caja(env, BW, .9, .3, wx(BW / 2), PB - .9, 0.05, MAT.piedra);
      caja(env, 3.5, PB - .9, .3, wx(1.75), 0, .05, MAT.piedra);
      caja(env, .6, PB - .9, .3, wx(3.8), 0, .05, MAT.piedra); caja(env, .5, PB - .9, .3, wx(10.35), 0, .05, MAT.piedra);
      caja(env, .5, PB - .9, .3, wx(15.0), 0, .05, MAT.piedra); caja(env, .6, PB - .9, .3, wx(25.1), 0, .05, MAT.piedra);
      [[4.2, 10.0], [15.3, 24.8]].forEach(([a, b]) => {
        caja(env, b - a, PB - .95, .06, wx((a + b) / 2), .05, -.05, vidrio(), false);
        for (let x = a; x <= b + .01; x += (b - a) / Math.round((b - a) / 1.8)) caja(env, .07, PB - .95, .12, wx(x), .05, 0, MAT.carpinteria);
        caja(env, b - a, .08, .12, wx((a + b) / 2), 0, 0, MAT.carpinteria);
      });
      // rótulo del centro de salud
      const r = new THREE.Mesh(new THREE.PlaneGeometry(9, .62), rotulo(nb === 1 ? 'CENTRO DE SALUD · ATENCIÓN PRIMARIA' : 'CENTRO DE SALUD · ESPECIALIDADES', { color: '#1F3A5F', px: 54, w: 1400, h: 96 }));
      r.position.set(wx(nb === 1 ? 20 : 20), PB - .48, .23); env.add(r);
      const cruz = new THREE.Group(); cruz.position.set(wx(nb === 1 ? 14.9 : 14.9) + 1.6, PB - .48, .24);
      // portal de viviendas
      caja(env, 3.6, PB - .9, .08, wx(12.7), 0, -.25, vidrio(), false);
      caja(env, 1.3, 2.6, .1, wx(12.7), 0, -.2, MAT.madera);
      caja(env, 4.6, .14, 1.8, wx(12.7), 3.0, .7, MAT.forjado);
      const num = new THREE.Mesh(new THREE.PlaneGeometry(1.4, .7), rotulo('Nº 4', { color: '#1F3A5F', px: 90, w: 256, h: 128, fuente: 'Playfair Display, Georgia, serif' })); num.position.set(wx(14.1), 2.55, .28); env.add(num);
      // rampa de garaje (bloque 1) o puerta de instalaciones (bloque 2)
      caja(env, 3.1, 2.5, .1, wx(1.75), 0, .22, nb === 1 ? MAT.carpinteria : MAT.estucoOscuro);
      if (nb === 1) { const rg = new THREE.Mesh(new THREE.PlaneGeometry(2.8, .32), rotulo('GARAJE · 40 PLAZAS', { color: '#ffffff', px: 46, w: 640, h: 72 })); rg.position.set(wx(1.75), 2.7, .29); env.add(rg); }
      // laterales y trasera
      caja(env, .3, PB - .35, BD, wx(.15), 0, wz(BD / 2), MAT.piedra); caja(env, .3, PB - .35, BD, wx(BW - .15), 0, wz(BD / 2), MAT.piedra);
      caja(env, BW, PB - .35, .3, wx(BW / 2), 0, wz(.15), MAT.piedra);
      for (let k = 0; k < 7; k++) caja(env, 1.8, 1.4, .06, wx(4.9 + k * 2.8), 1.2, wz(-.02), vidrio(), false);
      caja(env, .06, 1.6, 4.6, wx(BW + .02), 1.0, wz(8.5), vidrio(), false);
      // jardineras y bancos en la acera
      [5.5, 19.5].forEach(u => { caja(env, 2.4, .5, .7, wx(u), 0, 1.9, MAT.maceta); [-.7, 0, .7].forEach(d => arbusto(env, wx(u + d), .45, 1.9, .5)); });
    }
    // ---- Plantas 1 a 4: 4 viviendas ----
    for (let p = 1; p <= NP; p++) {
      const y0 = PB + (p - 1) * FH, est = new THREE.Group(), env = new THREE.Group(); g.add(est, env); B[p] = { est, env, y0, h: FH };
      // estructura: forjado y pilares
      caja(est, BW, .3, BD, wx(BW / 2), y0 + FH - .3, wz(BD / 2), MAT.hormigon);
      caja(est, 11.4, .3, 2, wx(12.7), y0 + FH - .3, 0, MAT.hormigon); // vuelo terrazas (techo de la planta inferior)
      for (let i = 0; i <= 5; i++) for (let j = 0; j <= 3; j++) caja(est, .35, FH - .3, .35, wx(.4 + i * (BW - .8) / 5), y0, wz(.4 + j * (BD - .8) / 3), MAT.hormigon);
      // cantos de forjado blancos
      caja(env, BW + .1, .32, .1, wx(BW / 2), y0 - .02, .03, MAT.forjado);
      caja(env, 11.4, .26, 2.02, wx(12.7), y0 - .26 + .26, 0, MAT.forjado);
      const yv = y0 + .26, hv = FH - .26;
      // fachada principal · dormitorios (u 0..7 y 18,4..25,4) con lamas de roble
      [[0, 7, [[1, 3.8], [4.5, 6.5]]], [18.4, 25.4, [[18.9, 20.9], [21.6, 24.4]]]].forEach(([a, b, ventanas]) => {
        let x = a;
        ventanas.forEach(([va, vb]) => {
          if (va > x) { caja(env, va - x, hv, .3, wx((x + va) / 2), yv, -.15, MAT.estuco); }
          caja(env, vb - va, .55, .3, wx((va + vb) / 2), yv, -.15, MAT.estuco); caja(env, vb - va, .35, .3, wx((va + vb) / 2), yv + hv - .35, -.15, MAT.estuco);
          caja(env, vb - va, hv - .9, .06, wx((va + vb) / 2), yv + .55, -.12, vidrio(), false);
          caja(env, vb - va + .1, .06, .2, wx((va + vb) / 2), yv + .52, -.02, MAT.carpinteria);
          caja(env, .06, hv - .9, .14, wx((va + vb) / 2), yv + .55, -.08, MAT.carpinteria);
          x = vb;
        });
        if (b > x) caja(env, b - x, hv, .3, wx((x + b) / 2), yv, -.15, MAT.estuco);
        lamas(wx(a + .25), wx(a + .85), yv, hv, .06); lamas(wx(b - .85), wx(b - .25), yv, hv, .06);
      });
      // salones retranqueados (u 7..18,4) con terraza volada y vidrio
      caja(env, .25, hv, 2.2, wx(7.12), yv, -.1, MAT.estuco); caja(env, .25, hv, 2.2, wx(18.28), yv, -.1, MAT.estuco);
      caja(env, .12, hv, 2.0, wx(12.7), yv, 0, MAT.estuco);
      [[7.6, 12.2], [13.2, 17.8]].forEach(([a, b]) => {
        caja(env, b - a, hv - .25, .06, wx((a + b) / 2), yv, -1.0, vidrio(), false);
        for (let x = a; x <= b + .01; x += (b - a) / 3) caja(env, .06, hv - .25, .12, wx(x), yv, -.98, MAT.carpinteria);
        caja(env, b - a + .4, .25, .2, wx((a + b) / 2), yv + hv - .25, -1.0, MAT.estuco);
      });
      caja(env, .5, hv, .2, wx(7.35), yv, -1.0, MAT.estuco); caja(env, .5, hv, .2, wx(18.05), yv, -1.0, MAT.estuco);
      caja(env, 1.0, hv, .2, wx(12.7), yv, -1.0, MAT.estuco);
      // barandilla de vidrio y vida en la terraza
      caja(env, 11.0, 1.05, .04, wx(12.7), yv, .98, MAT.barandilla, false);
      caja(env, 11.0, .05, .08, wx(12.7), yv + 1.05, .98, MAT.alu);
      [[9.2, 1], [16.2, -1]].forEach(([u, s]) => {
        caja(env, 1.6, .45, .4, wx(u + s * 2.0), yv, .65, MAT.maceta);
        [-.45, .45].forEach(d => arbusto(env, wx(u + s * 2.0 + d), yv + .42, .65, .42));
        cil(env, .45, .45, .04, wx(u), yv + .72, -.1, MAT.madera, 24); cil(env, .04, .04, .72, wx(u), yv, -.1, MAT.carpinteria, 8);
        [-1, 1].forEach(d => { const cx = wx(u + d * .8); caja(env, .46, .05, .46, cx, yv + .44, -.1, MAT.madera); caja(env, .46, .42, .05, cx + d * .21 * 0, yv + .49, -.1 + .2, MAT.madera); [[-.19, -.19], [.19, -.19], [-.19, .19], [.19, .19]].forEach(([a, b]) => caja(env, .04, .44, .04, cx + a, yv, -.1 + b, MAT.carpinteria)); });
        caja(env, .7, .3, 1.8, wx(u - s * 2.6), yv + .1, -.1, MAT.textil); caja(env, .5, .1, .3, wx(u - s * 2.6), yv + .42, -.8, MAT.cojin);
        // toldo enrollado/extendido
        const t = caja(env, 4.4, .03, 1.7, wx(u + s * .2), yv + hv - .45, -.1, M({ color: 0xe7dcc6, roughness: 1, side: THREE.DoubleSide })); t.rotation.x = .12;
      });
      // laterales con ventanas
      [0, BW].forEach(u => {
        const s = u ? 1 : -1, xx = wx(u) + s * .0;
        [[0, 1], [3, 5], [7, 9], [11, 15], [17, 18]].forEach(([a, b]) => caja(env, .3, hv, b - a, xx - s * .15, yv, wz((a + b) / 2), MAT.estuco));
        [[1, 3], [5, 7], [9, 11], [15, 17]].forEach(([a, b]) => {
          caja(env, .3, .55, b - a, xx - s * .15, yv, wz((a + b) / 2), MAT.estuco); caja(env, .3, .35, b - a, xx - s * .15, yv + hv - .35, wz((a + b) / 2), MAT.estuco);
          caja(env, .06, hv - .9, b - a, xx - s * .12, yv + .55, wz((a + b) / 2), vidrio(), false);
        });
      });
      // trasera: dormitorios, baños, terraza de salón y cocina
      const tras = [[0, 1], [3.8, 4.3], [5.2, 5.7], [10.7, 11.2], [12.4, 13.0], [14.2, 14.7], [19.7, 20.2], [21.1, 21.6], [24.4, 25.4]];
      tras.forEach(([a, b]) => caja(env, b - a, hv, .3, wx((a + b) / 2), yv, wz(.15), MAT.estuco));
      [[1, 3.8], [4.3, 5.2], [11.2, 12.4], [13.0, 14.2], [20.2, 21.1], [21.6, 24.4]].forEach(([a, b]) => {
        caja(env, b - a, .55, .3, wx((a + b) / 2), yv, wz(.15), MAT.estuco); caja(env, b - a, .35, .3, wx((a + b) / 2), yv + hv - .35, wz(.15), MAT.estuco);
        caja(env, b - a, hv - .9, .06, wx((a + b) / 2), yv + .55, wz(.12), vidrio(), false);
      });
      [[5.7, 10.7], [14.7, 19.7]].forEach(([a, b]) => {
        caja(env, b - a, hv, .06, wx((a + b) / 2), yv, wz(2.0), vidrio(), false);
        caja(env, b - a, 1.0, .04, wx((a + b) / 2), yv, wz(.05), MAT.barandilla, false);
        caja(env, .25, hv, 2, wx(a), yv, wz(1), MAT.estuco); caja(env, .25, hv, 2, wx(b), yv, wz(1), MAT.estuco);
      });
    }
    // ---- Cubierta: peto, placas solares y casetón ----
    {
      const y0 = PB + NP * FH, est = new THREE.Group(), env = new THREE.Group(); g.add(est, env); B[5] = { est, env, y0, h: 1 };
      caja(est, BW, .3, BD, wx(BW / 2), y0 - .3, wz(BD / 2), MAT.hormigon);
      caja(env, BW + .1, .9, .25, wx(BW / 2), y0, .0, MAT.forjado); caja(env, BW + .1, .9, .25, wx(BW / 2), y0, wz(0), MAT.forjado);
      caja(env, .25, .9, BD, wx(0), y0, wz(BD / 2), MAT.forjado); caja(env, .25, .9, BD, wx(BW), y0, wz(BD / 2), MAT.forjado);
      caja(env, 4.4, 2.6, 6.4, wx(12.7), y0, wz(9), MAT.estuco);
      for (let i = 0; i < 9; i++) for (let j = 0; j < 4; j++) {
        if (i === 4) continue;
        const m = caja(env, 1.05, .04, 1.9, wx(1.6 + i * 2.65), y0 + .45, wz(2 + j * 2.4 + (j > 1 ? 7.6 : 0)), MAT.solar); m.rotation.x = -.22;
        caja(env, .05, .45, .05, wx(1.6 + i * 2.65), y0, wz(2 + j * 2.4 + (j > 1 ? 7.6 : 0)) + .7, MAT.alu);
      }
    }
    // hitboxes por planta
    for (let p = 0; p <= NP; p++) {
      const y0 = p === 0 ? 0 : PB + (p - 1) * FH, h = p === 0 ? PB : FH;
      const m = new THREE.Mesh(new THREE.BoxGeometry(BW + .6, h - .05, BD + 2.6), new THREE.MeshBasicMaterial({ visible: false }));
      m.position.set(wx(BW / 2), y0 + h / 2, wz(BD / 2) + .7); m.userData = { bloque: nb, planta: p, y0, h, cx: wx(BW / 2) }; hit.add(m);
    }
  }
  bloque(1, X1); bloque(2, X2);
  {
    const im = new THREE.InstancedMesh(lamaGeo, MAT.madera, lamasM.length); const o = new THREE.Object3D();
    lamasM.forEach(([x, y, z, h], i) => { o.position.set(x, y, z); o.scale.set(1, h, 1); o.updateMatrix(); im.setMatrixAt(i, o.matrix); });
    im.castShadow = true; im.receiveShadow = true; edificio.add(im); edificio.userData.lamas = im;
  }
  // espacio entre bloques: paso ajardinado
  caja(scene, GAP - .4, .2, BD, 0, 0, -BD / 2, M({ color: 0xcfc4b2, roughness: .9 }), false);
  [-6, -12].forEach(z => { const a = arbol(0, z, .75, 'olivo'); });
  // marquesina de seguridad durante la obra / grúa
  const grua = new THREE.Group(); scene.add(grua); grua.visible = false;
  {
    for (let k = 0; k < 14; k++) caja(grua, 1.6, 2.4, 1.6, 0, k * 2.4, -9, MAT.grua).material = MAT.grua;
    const pluma = caja(grua, 48, 1.0, 1.0, 14, 33.6, -9, MAT.grua); caja(grua, 12, 1.4, 1.4, -11, 33.4, -9, MAT.hormigon);
    caja(grua, 2.4, 2.2, 2.4, 0, 33.6, -9, M({ color: 0xffffff }));
    const cable = caja(grua, .04, 18, .04, 26, 16, -9, MAT.carpinteria);
  }
  const valla = new THREE.Group(); scene.add(valla); valla.visible = false;
  caja(valla, 64, 2.0, .06, 0, 0, .9, M({ color: 0xffffff, roughness: .8 }));
  const lona = new THREE.Mesh(new THREE.PlaneGeometry(16, 1.6), rotulo('PRÓXIMA PROMOCIÓN · 32 VIVIENDAS + CENTRO DE SALUD', { color: '#1F3A5F', px: 44, w: 1600, h: 160, fondo: '#f4f1ea' })); lona.position.set(0, 1.05, .95); valla.add(lona);
  // excavación y sótano (40 plazas)
  const sotano = new THREE.Group(); scene.add(sotano);
  {
    const SD = 3.4, ancho = 62.8 - 6, prof = BD;
    caja(sotano, ancho, .3, prof, 0, -SD - .3, -prof / 2, MAT.hormigon, false);
    caja(sotano, ancho, SD, .3, 0, -SD, 0, MAT.hormigon); caja(sotano, ancho, SD, .3, 0, -SD, -prof, MAT.hormigon);
    caja(sotano, .3, SD, prof, -ancho / 2, -SD, -prof / 2, MAT.hormigon); caja(sotano, .3, SD, prof, ancho / 2, -SD, -prof / 2, MAT.hormigon);
    const linea = M({ color: 0xffffff, roughness: .6 });
    let n = 0; const plazas = [];
    for (let fila = 0; fila < 2; fila++) for (let k = 0; k < 20; k++) {
      const x = -ancho / 2 + 2.6 + k * 2.6 + (k >= 10 ? .6 : 0), z = fila ? -2.6 : -prof + 2.6;
      caja(sotano, .1, .02, 5, x - 1.3, -SD, z, linea, false); plazas.push([x, z]); n++;
    }
    plazas.forEach(([x, z], i) => { if (i % 3 === 1) return; const c = coche(0, 0, 0, COCHES[i % COCHES.length]); entorno.remove(c); c.position.set(x, -SD, z); sotano.add(c); });
    const rot = new THREE.Mesh(new THREE.PlaneGeometry(12, 1.2), rotulo('SÓTANO · 40 PLAZAS DE GARAJE · 1.218 m²', { color: '#ffffff', px: 52, w: 1400, h: 128 })); rot.rotation.x = -Math.PI / 2; rot.position.set(0, -SD + .03, -BD / 2); sotano.add(rot);
    sotano.userData.n = n;
  }
  sotano.visible = false;
  // el cielo de Sky es HDR: se atenúa su reflejo en los materiales mates
  // los colores hex son sRGB: se pasan a lineal una sola vez (si no, todo sale lavado)
  const hechos = new Set();
  function linealizar(root) {
    root.traverse(o => {
      if (!o.isMesh || !o.material) return; [].concat(o.material).forEach(m => {
        if (hechos.has(m)) return; hechos.add(m);
        if (m.color && !m.map) m.color.convertSRGBToLinear(); if (m.emissive) m.emissive.convertSRGBToLinear();
        if (m.isMeshStandardMaterial && !m.isMeshPhysicalMaterial) m.envMapIntensity = .35;
      });
    });
  }
  linealizar(scene);

  // ---------- Hora del día (verano en Oropesa) ----------
  let horaActual = 19, envT = 0;
  function solVerano(h) {
    const ini = 6.75, fin = 21.45, t = Math.min(1, Math.max(0, (h - ini) / (fin - ini)));
    const elev = Math.max(-4, 72 * Math.sin(Math.PI * t)) * Math.PI / 180, az = (62 + t * 236) * Math.PI / 180;
    return { elev, dir: new THREE.Vector3(Math.sin(az) * Math.cos(elev), Math.sin(elev), -Math.cos(az) * Math.cos(elev)) };
  }
  function hora(h, rapido) {
    horaActual = h; const s = solVerano(h), e = Math.max(0, s.elev) / (72 * Math.PI / 180);
    su.sunPosition.value.copy(s.dir);
    sun.position.copy(s.dir).multiplyScalar(260); sun.target.position.set(0, 0, -8);
    const baja = 1 - Math.min(1, e * 2.2);
    sun.color.setHSL(.09 - .04 * baja, .55 + .4 * baja, .78 - .14 * baja);
    sun.intensity = s.elev > 0 ? 1.4 + 2.2 * Math.pow(e, .55) : 0;
    hemi.intensity = .35 + .45 * Math.pow(e, .5);
    hemi.color.setHSL(.58, .55, .62 - .1 * baja);
    renderer.toneMappingExposure = .56 + .16 * (1 - e);
    scene.fog.color.setHSL(.57 - .5 * baja * .12, .3 + .3 * baja, .78 - .1 * baja);
    const luz = Math.max(0, Math.min(1, (h - 19.6) / 1.4));
    VIDRIOS.forEach(m => m.emissiveIntensity = luz * .55);
    if (!rapido) actualizarEntorno(); else { clearTimeout(envT); envT = setTimeout(actualizarEntorno, 250); }
    pedir();
  }
  function actualizarEntorno() {
    const sc = new THREE.Scene(); const s2 = new THREE.Sky(); s2.scale.setScalar(1000); s2.material.uniforms.sunPosition.value.copy(su.sunPosition.value);
    ['turbidity', 'rayleigh', 'mieCoefficient', 'mieDirectionalG'].forEach(k => s2.material.uniforms[k].value = su[k].value); sc.add(s2);
    const nuevo = pmrem.fromScene(sc); if (envRT) envRT.dispose(); envRT = nuevo; scene.environment = envRT.texture; pedir();
  }

  // ---------- 4D: obra ----------
  // meses: 0-12 trámites (solar sin tocar) · 12-15 excavación y sótano · 15-21 estructura · 18-27 fachadas · 27-30 acabados · 30-32 entrega
  let mesObra = null;
  function obra(m) {
    mesObra = m; const fin = m == null || m >= 30;
    solarActual.visible = m != null && m < 12;
    zonaVerde.visible = fin || (m != null && m >= 27);
    valla.visible = m != null && m >= 8 && m < 30;
    grua.visible = m != null && m >= 12.5 && m < 25;
    edificio.visible = m == null || m >= 15;
    sotano.visible = verSotano || (m != null && m >= 12 && m < 16.5);
    const pEst = m == null ? 99 : (m - 15) / 6 * 6, pEnv = m == null ? 99 : (m - 18) / 9 * 6;
    PLANTAS.forEach(B => B.forEach((pl, i) => { pl.est.visible = pEst >= i; pl.env.visible = pEnv >= i + 1 || fin; }));
    if (edificio.userData.lamas) edificio.userData.lamas.visible = fin || pEnv >= 5;
    hit.visible = fin; pedir();
  }
  let verSotano = false;
  const transp = [];
  function sotanoVer(b) {
    verSotano = b; sotano.visible = b || (mesObra != null && mesObra >= 12 && mesObra < 16.5);
    if (!transp.length) edificio.traverse(o => { if (o.isMesh && o.material && !o.material.transparent) transp.push(o.material); });
    [...new Set(transp)].forEach(mt => { mt.transparent = b; mt.opacity = b ? .18 : 1; mt.depthWrite = !b; mt.needsUpdate = true; });
    suelo.visible = !b; pedir();
  }

  // ---------- Cámara ----------
  const VISTAS = {
    esquina: [[-34, 18, 60], [12, 8, -6]],
    frente: [[8, 9, 56], [17, 8, -6]],
    calle: [[-12, 1.7, CALLE_Z + CALZ + 2.2], [-4, 9, -4]],
    aerea: [[40, 74, 72], [12, 2, -10]],
    trasera: [[27, 18, -46], [0, 7, -9]],
    sotano: [[-30, 26, 40], [0, -3, -9]]
  };
  function vista(n, ms = 1600) {
    const v = VISTAS[n] || VISTAS.esquina, p0 = cam.position.clone(), t0 = ctr.target.clone(), p1 = new THREE.Vector3(...v[0]), t1 = new THREE.Vector3(...v[1]), s = performance.now();
    (function mv() { const k = Math.min(1, (performance.now() - s) / ms), e = 1 - Math.pow(1 - k, 3); cam.position.lerpVectors(p0, p1, e); ctr.target.lerpVectors(t0, t1, e); ctr.update(); pedir(); if (k < 1) requestAnimationFrame(mv); })();
  }

  // ---------- Interacción ----------
  const ray = new THREE.Raycaster(), ptr = new THREE.Vector2(); let hov = null, downAt = null;
  function pick(e) {
    const r = renderer.domElement.getBoundingClientRect(); ptr.set((e.clientX - r.left) / r.width * 2 - 1, -(e.clientY - r.top) / r.height * 2 + 1);
    ray.setFromCamera(ptr, cam); if (!hit.visible) return null; const i = ray.intersectObjects(hit.children)[0]; return i ? i.object : null;
  }
  function marcar(o) {
    if (o === hov) return; hov = o;
    if (o) { const d = o.userData; glow.visible = true; glow.position.set(d.cx, d.y0 + d.h / 2, -BD / 2 + .7); glow.scale.set(BW + .7, d.h - .08, BD + 2.7); renderer.domElement.style.cursor = 'pointer'; }
    else { glow.visible = false; renderer.domElement.style.cursor = 'grab'; }
    EXT.onHover && EXT.onHover(o ? o.userData : null); pedir();
  }
  function enlazar() {
    const el = renderer.domElement;
    el.addEventListener('pointermove', e => marcar(pick(e)));
    el.addEventListener('pointerleave', () => marcar(null));
    el.addEventListener('pointerdown', e => { downAt = [e.clientX, e.clientY]; ctr.autoRotate = false; EXT.onStopGiro && EXT.onStopGiro(); });
    el.addEventListener('pointerup', e => { if (!downAt || Math.hypot(e.clientX - downAt[0], e.clientY - downAt[1]) > 6) return; const o = pick(e); if (o) EXT.onClick && EXT.onClick(o.userData); });
    ctr.addEventListener('change', pedir);
  }
  function resaltar(bl, pl) { const o = hit.children.find(h => h.userData.bloque === bl && h.userData.planta === pl); marcar(o || null); }

  // ---------- Bucle ----------
  function size() { if (!host) return; W = host.clientWidth || 1; H = host.clientHeight || 1; renderer.setSize(W, H); cam.aspect = W / H; cam.updateProjectionMatrix(); if (composer) { composer.setPixelRatio(renderer.getPixelRatio()); composer.setSize(W, H); } pedir(); }
  addEventListener('resize', size);
  const etiquetas = []; let capaEt = null;
  function etiqueta(txt, pos, cls = '') { const e = document.createElement('div'); e.className = 'ex-lb ' + cls; e.innerHTML = txt; capaEt.appendChild(e); etiquetas.push({ e, v: new THREE.Vector3(...pos) }); }
  const tmp = new THREE.Vector3();
  // ---------- Alta calidad: oclusión ambiental (sombras de contacto) y corrección de color ----------
  let composer = null, ssao = null, alta = false;
  function preparar() {
    if (composer || !THREE.EffectComposer || !THREE.SSAOPass) return false;
    composer = new THREE.EffectComposer(renderer);
    ssao = new THREE.SSAOPass(scene, cam, W, H); ssao.kernelRadius = 1.1; ssao.minDistance = .00015; ssao.maxDistance = .006;
    composer.addPass(ssao); composer.addPass(new THREE.ShaderPass(THREE.GammaCorrectionShader));
    return true;
  }
  function calidad(b) { alta = false; if (composer) { composer.setPixelRatio(renderer.getPixelRatio()); composer.setSize(W, H); } pedir(); }
  function pedir() { if (!rafPend) { rafPend = true; requestAnimationFrame(frame); } }
  function frame() {
    rafPend = false; if (!activo) return;
    if (ctr.autoRotate || ctr.enableDamping) ctr.update();
    if (alta && composer) composer.render(); else renderer.render(scene, cam);
    etiquetas.forEach(({ e, v }) => { tmp.copy(v).project(cam); const vis = tmp.z < 1 && Math.abs(tmp.x) < 1.1 && Math.abs(tmp.y) < 1.1; e.style.opacity = vis ? 1 : 0; e.style.transform = `translate(-50%,-100%) translate(${(tmp.x + 1) / 2 * W}px,${(1 - tmp.y) / 2 * H}px)`; });
    if (ctr.autoRotate) pedir();
  }
  // con amortiguación hay que seguir pintando unos fotogramas tras soltar
  let inercia = 0; ctr.addEventListener('end', () => { inercia = performance.now(); (function seguir() { pedir(); if (performance.now() - inercia < 1200) requestAnimationFrame(seguir); })(); });

  window.EXT = {
    montar(el) {
      host = el; el.appendChild(renderer.domElement); renderer.domElement.style.cursor = 'grab';
      capaEt = document.createElement('div'); capaEt.className = 'ex-labels'; el.appendChild(capaEt);
      etiqueta('Bloque 1', [X1 + BW / 2, TOP + 3.4, -BD / 2]); etiqueta('Bloque 2', [X2 + BW / 2, TOP + 3.4, -BD / 2]);
      etiqueta('Calle Vinaroz', [-22, .5, CALLE_Z + CALZ / 2], 'calle');
      etiqueta('Mar · playa a ~3 min', [240, 2, -20], 'calle');
      enlazar(); size(); hora(horaActual); obra(null); pedir();
    },
    hora, vista, obra, sotano: sotanoVer, resaltar, calidad,
    girar(b) { ctr.autoRotate = b; pedir(); },
    activar(b) { activo = b; if (b) { size(); pedir(); } },
    etiquetas(b) { if (capaEt) capaEt.style.display = b ? '' : 'none'; },
    sombras(n) { sun.shadow.mapSize.set(n, n); if (sun.shadow.map) { sun.shadow.map.dispose(); sun.shadow.map = null; } },
    foto(w, h) { const a = [W, H]; renderer.setPixelRatio(1); renderer.setSize(w, h); cam.aspect = w / h; cam.updateProjectionMatrix(); renderer.render(scene, cam); const url = renderer.domElement.toDataURL('image/jpeg', .9); renderer.setPixelRatio(Math.min(devicePixelRatio, 2)); size(); return url; },
    enfocar(bl, pl, ms = 1100) {
      const o = hit.children.find(h => h.userData.bloque === bl && h.userData.planta === pl); if (!o) return;
      const d = o.userData, y = d.y0 + d.h / 2;
      VISTAS._f = [[d.cx + (bl === 1 ? -9 : 9), y + 3, 24], [d.cx, y, -4]]; vista('_f', ms);
    },
    camara(p, t) { cam.position.set(...p); ctr.target.set(...t); ctr.update(); pedir(); },
    get hor() { return horaActual; }, solVerano
  };
})();
