/* Edificio interactivo · motor 3D de viviendas (varias tipologías y estilos)
   Mismo formato de trazado que la skill plano-3d. No se toca por edificio.
   API: P3D.montar(el) · .cargar(datosTipologia) · .amueblar(estilo) · .vista('maqueta'|'aerea'|'baja') · .girar(b) · .etiquetas(b) · .activar(b)
   Estilos: vacio · nordico · moderno · japandi · deco · mediterraneo */
(function () {
  let host, PX = 100, CX = 0, CZ = 0, T = 1.15;
  const X = p => (p - CX) / PX, Z = p => (p - CZ) / PX;
  const RB = THREE.RoundedBoxGeometry;

  const scene = new THREE.Scene();
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputEncoding = THREE.sRGBEncoding;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.0;
  renderer.physicallyCorrectLights = true;
  if (THREE.RoomEnvironment) {
    const pm = new THREE.PMREMGenerator(renderer);
    scene.environment = pm.fromScene(new THREE.RoomEnvironment(), 0.04).texture;
  }
  const cam = new THREE.PerspectiveCamera(32, 1, 0.1, 300);
  let VISTAS = { maqueta: [6.5, 13, 9], aerea: [0, 17, 0.01], baja: [9, 3.8, 7.5] };
  cam.position.set(...VISTAS.maqueta);
  const ctr = new THREE.OrbitControls(cam, renderer.domElement);
  ctr.target.set(0, 0, 0.3);
  ctr.enableDamping = true; ctr.dampingFactor = 0.06;
  ctr.minDistance = 3; ctr.maxDistance = 45;
  ctr.maxPolarAngle = Math.PI * 0.47;
  ctr.autoRotate = true; ctr.autoRotateSpeed = 0.45;
  ctr.enablePan = false;

  const hemi = new THREE.HemisphereLight(0xfff6ec, 0x3a3029, 0.6); scene.add(hemi);
  const sun = new THREE.DirectionalLight(0xffe7cf, 3.2);
  sun.position.set(-6, 12, -4);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  Object.assign(sun.shadow.camera, { left: -14, right: 14, top: 14, bottom: -14, near: 1, far: 50 });
  sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.02; sun.shadow.radius = 5;
  scene.add(sun);

  // ---------- Texturas procedurales ----------
  function lienzo(n, draw) { const c = document.createElement('canvas'); c.width = c.height = n; draw(c.getContext('2d'), n); return c; }
  function tex(c, rx, ry, color = true) {
    const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rx, ry || rx);
    if (color) t.encoding = THREE.sRGBEncoding; t.anisotropy = renderer.capabilities.getMaxAnisotropy(); return t;
  }
  const rnd = (a, b) => a + Math.random() * (b - a);
  function parquet(h, s, l) {
    return lienzo(1024, (g, n) => {
      const filas = 8, alto = n / filas;
      for (let i = 0; i < filas; i++) {
        let x = -rnd(0, n / 2);
        while (x < n) {
          const largo = rnd(n * 0.45, n * 0.9), L = l + rnd(-5, 5);
          g.fillStyle = `hsl(${h + rnd(-3, 3)},${s}%,${L}%)`; g.fillRect(x, i * alto, largo, alto);
          for (let k = 0; k < 26; k++) {
            g.strokeStyle = `hsla(${h - 6},${s + 10}%,${L - 18}%,${rnd(.04, .14)})`; g.lineWidth = rnd(.6, 1.6);
            const y = i * alto + rnd(2, alto - 2); g.beginPath(); g.moveTo(x, y);
            g.bezierCurveTo(x + largo * .3, y + rnd(-3, 3), x + largo * .6, y + rnd(-3, 3), x + largo, y + rnd(-2, 2)); g.stroke();
          }
          if (Math.random() < .35) { g.fillStyle = `hsla(${h - 8},40%,${L - 22}%,.25)`; g.beginPath(); g.ellipse(x + rnd(20, largo - 20), i * alto + alto / 2, rnd(4, 9), rnd(2, 4), 0, 0, 7); g.fill(); }
          g.fillStyle = 'rgba(40,25,15,.45)'; g.fillRect(x, i * alto, 1.5, alto);
          x += largo;
        }
        g.fillStyle = 'rgba(40,25,15,.4)'; g.fillRect(0, i * alto, n, 1.5);
      }
    });
  }
  function rugosidad(base, ruido) {
    return lienzo(256, (g, n) => { const d = g.createImageData(n, n); for (let i = 0; i < d.data.length; i += 4) { const v = base + (Math.random() - .5) * ruido; d.data[i] = d.data[i + 1] = d.data[i + 2] = v; d.data[i + 3] = 255; } g.putImageData(d, 0, 0); });
  }
  function baldosas(cols, filas, hsl, junta) {
    return lienzo(1024, (g, n) => {
      g.fillStyle = junta; g.fillRect(0, 0, n, n);
      const w = n / cols, h = n / filas;
      for (let x = 0; x < cols; x++) for (let y = 0; y < filas; y++) {
        const [H, S, L] = hsl; g.fillStyle = `hsl(${H},${S}%,${L + rnd(-2.5, 2.5)}%)`; g.fillRect(x * w + 3, y * h + 3, w - 6, h - 6);
        for (let k = 0; k < 120; k++) { g.fillStyle = `hsla(${H},${S}%,${L + rnd(-10, 10)}%,.25)`; g.fillRect(x * w + rnd(3, w - 6), y * h + rnd(3, h - 6), rnd(1, 4), rnd(1, 4)); }
      }
    });
  }
  function tejido(hex) {
    return lienzo(256, (g, n) => {
      g.fillStyle = hex; g.fillRect(0, 0, n, n);
      for (let y = 0; y < n; y += 2) { g.fillStyle = `rgba(0,0,0,${rnd(.02, .07)})`; g.fillRect(0, y, n, 1); }
      for (let x = 0; x < n; x += 2) { g.fillStyle = `rgba(255,255,255,${rnd(.02, .06)})`; g.fillRect(x, 0, 1, n); }
    });
  }

  const T_ROBLE = parquet(32, 42, 66), T_NOGAL = parquet(24, 38, 34), T_FRESNO = parquet(36, 30, 74);
  const R_MADERA = rugosidad(150, 70);
  // parquet en espiga para el estilo clásico
  function espiga(h, s, l) {
    return lienzo(1024, (g, n) => {
      g.fillStyle = `hsl(${h},${s}%,${l - 8}%)`; g.fillRect(0, 0, n, n);
      const L = 160, W = 40;
      for (let y = -L; y < n + L; y += W * 2) for (let x = -L; x < n + L; x += W * 2) {
        [[0, 1], [1, -1]].forEach(([o, d], k) => {
          g.save(); g.translate(x + k * W, y); g.rotate(d * Math.PI / 4);
          g.fillStyle = `hsl(${h + rnd(-3, 3)},${s}%,${l + rnd(-5, 5)}%)`; g.fillRect(0, 0, L, W - 2);
          for (let q = 0; q < 6; q++) { g.strokeStyle = `hsla(${h - 6},${s + 8}%,${l - 18}%,${rnd(.05, .15)})`; g.beginPath(); const yy = rnd(3, W - 5); g.moveTo(0, yy); g.lineTo(L, yy + rnd(-2, 2)); g.stroke(); }
          g.restore();
        });
      }
    });
  }
  const SUELOS_ESTILO = {
    clasico: espiga(28, 40, 50),
    vacio: parquet(30, 40, 60), nordico: parquet(34, 38, 70), moderno: parquet(24, 36, 38),
    japandi: parquet(36, 32, 72), deco: parquet(22, 46, 42), mediterraneo: baldosas(5, 5, [16, 52, 52], '#d9c9b4')
  };

  function M(o) { return new THREE.MeshStandardMaterial(Object.assign({ envMapIntensity: 0.9 }, o)); }
  function madera(c, rep = 1) { return M({ map: tex(c, rep), roughnessMap: tex(R_MADERA, rep, rep, false), roughness: .62 }); }
  function tela(hex, rep = 3) { return M({ map: tex(tejido(hex), rep), roughness: 1, envMapIntensity: .5 }); }

  const MAT = {
    pared: M({ color: 0xf4efe8, roughness: .95 }),
    canto: M({ color: 0x1a1714, roughness: .55 }),
    losa: M({ color: 0x24201c, roughness: .8 }),
    cristal: new THREE.MeshPhysicalMaterial({ color: 0xdff1ff, transparent: true, opacity: .28, roughness: .03, metalness: 0, envMapIntensity: 1.6 }),
    sueloBaldosa: baldosas(4, 4, [30, 10, 82], '#b9b0a6'), sueloGres: baldosas(2, 4, [30, 3, 46], '#3b3835'), sueloExterior: baldosas(3, 6, [28, 8, 62], '#8d857c'),
    porcelana: new THREE.MeshPhysicalMaterial({ color: 0xffffff, roughness: .12, clearcoat: 1, clearcoatRoughness: .08, envMapIntensity: 1.2 }),
    cromo: M({ color: 0xdddddd, metalness: 1, roughness: .12, envMapIntensity: 1.4 }),
    agua: new THREE.MeshPhysicalMaterial({ color: 0x9fd8e4, roughness: .02, transparent: true, opacity: .75, envMapIntensity: 1.5 }),
    piscina: new THREE.MeshPhysicalMaterial({ color: 0x0f9fbf, emissive: 0x06708a, emissiveIntensity: .45, roughness: .04, transparent: true, opacity: .95, envMapIntensity: 1.1 }),
    piedra: M({ color: 0xe8e2d8, roughness: .5 }),
    cristalDucha: new THREE.MeshPhysicalMaterial({ color: 0xeaf6ff, transparent: true, opacity: .22, roughness: .02, envMapIntensity: 1.5 }),
    pantalla: M({ color: 0x0b0b0c, roughness: .18, metalness: .2 }),
    hojas: M({ color: 0x4f6b3d, roughness: .75 }),
    hojas2: M({ color: 0x6d8a52, roughness: .75 })
  };

  const luzPantalla = (c, e) => M({ color: c, emissive: e, emissiveIntensity: .6, roughness: .9 });
  const ESTILOS = {
    nordico: {
      pared: 0xf6f3ee,
      madera: madera(T_ROBLE, 1.2), lacado: M({ color: 0xf3f0ea, roughness: .45 }), metal: M({ color: 0x1d1d1d, metalness: .6, roughness: .45 }),
      sofa: tela('#d8d2c8'), cojin1: tela('#9aab94'), cojin2: tela('#d6a84a'), alfombra: tela('#ece5d8', 6),
      ropaCama: tela('#f7f5f1'), manta: tela('#a9b8a2'), cabecero: tela('#cfc6b8'), maceta: M({ color: 0xe9e3da, roughness: .6 }),
      encimera: M({ color: 0xf2efe9, roughness: .25 }), frente: M({ color: 0xeeeae3, roughness: .4 }), pantalla: luzPantalla(0xfff1d6, 0xffe2b0)
    },
    moderno: {
      pared: 0xe9e4dd,
      madera: madera(T_NOGAL, 1.2), lacado: M({ color: 0x2a2826, roughness: .35 }), metal: M({ color: 0xb48b55, metalness: 1, roughness: .28 }),
      sofa: tela('#55534f'), cojin1: tela('#a5643c'), cojin2: tela('#d9d2c6'), alfombra: tela('#8f8a84', 6),
      ropaCama: tela('#e9e6e1'), manta: tela('#a5643c'), cabecero: tela('#4c4a47'), maceta: M({ color: 0x2b2927, roughness: .5 }),
      encimera: M({ color: 0x1e1d1c, roughness: .2 }), frente: M({ color: 0x3a3632, roughness: .35 }), pantalla: luzPantalla(0xfff1d6, 0xffd9a0)
    },
    japandi: {
      pared: 0xefe8de,
      madera: madera(T_FRESNO, 1.2), lacado: M({ color: 0xe4dacb, roughness: .55 }), metal: M({ color: 0x3b332c, metalness: .3, roughness: .6 }),
      sofa: tela('#cdbfa9'), cojin1: tela('#8c7a62'), cojin2: tela('#e8e0d2'), alfombra: tela('#d9cdb8', 6),
      ropaCama: tela('#efe8dc'), manta: tela('#a89377'), cabecero: tela('#b9a98f'), maceta: M({ color: 0x5b4f43, roughness: .8 }),
      encimera: M({ color: 0xd9d0c2, roughness: .35 }), frente: M({ color: 0xcdbfa9, roughness: .5 }), pantalla: luzPantalla(0xfdf3e1, 0xffe6bf)
    },
    deco: {
      pared: 0xf1e9dc,
      madera: madera(T_NOGAL, 1.2), lacado: M({ color: 0x14302a, roughness: .3 }), metal: M({ color: 0xd4a849, metalness: 1, roughness: .2 }),
      sofa: tela('#1f5a4a'), cojin1: tela('#c9a24a'), cojin2: tela('#7a2e3a'), alfombra: tela('#e7dcc6', 6),
      ropaCama: tela('#f4efe6'), manta: tela('#1f5a4a'), cabecero: tela('#2a4a42'), maceta: M({ color: 0xf2f0ec, metalness: .1, roughness: .15 }),
      encimera: new THREE.MeshPhysicalMaterial({ color: 0xf4f1ec, roughness: .08, clearcoat: 1, envMapIntensity: 1.3 }), frente: M({ color: 0x1a3a33, roughness: .3 }), pantalla: luzPantalla(0xffe9b8, 0xffcf70)
    },
    clasico: {
      pared: 0xf1e8d8,
      madera: madera(parquet(18, 52, 30), 1.2), lacado: M({ color: 0xeee3cc, roughness: .4 }), metal: M({ color: 0xb8924f, metalness: 1, roughness: .28 }),
      sofa: tela('#b9a27e'), cojin1: tela('#7a2e3a'), cojin2: tela('#2f4a3f'), alfombra: tela('#9a5a4a', 6),
      ropaCama: tela('#f5efe2'), manta: tela('#7a2e3a'), cabecero: tela('#5a3d2b'), maceta: M({ color: 0xc9a25b, metalness: .7, roughness: .3 }),
      encimera: new THREE.MeshPhysicalMaterial({ color: 0xf2eee8, roughness: .12, clearcoat: 1, envMapIntensity: 1.2 }), frente: M({ color: 0xe6dac0, roughness: .45 }), pantalla: luzPantalla(0xfdf0d2, 0xffd99a)
    },
    mediterraneo: {
      pared: 0xfbf8f2,
      madera: madera(T_ROBLE, 1.2), lacado: M({ color: 0xf8f5ee, roughness: .7 }), metal: M({ color: 0x8a6a45, metalness: .2, roughness: .7 }),
      sofa: tela('#efe7d8'), cojin1: tela('#c96f4a'), cojin2: tela('#3f6f8f'), alfombra: tela('#e2d3b6', 6),
      ropaCama: tela('#fbf8f2'), manta: tela('#c96f4a'), cabecero: tela('#c7a77c'), maceta: M({ color: 0xb8643f, roughness: .85 }),
      encimera: M({ color: 0xf3eee4, roughness: .45 }), frente: M({ color: 0xe9e1d1, roughness: .6 }), pantalla: luzPantalla(0xfff3dc, 0xffdca8)
    }
  };

  // ---------- Catálogo de muebles (metros; origen en el suelo; el frente mira a +z) ----------
  function pieza(g, geo, mat, x, y, z) { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = true; m.receiveShadow = true; g.add(m); return m; }
  const bx = (g, w, h, d, x, y, z, mat, r = .012) => pieza(g, r > 0 ? new RB(w, h, d, 3, Math.min(r, w / 2, h / 2, d / 2)) : new THREE.BoxGeometry(w, h, d), mat, x, y + h / 2, z);
  const cil = (g, rt, rb, h, x, y, z, mat, seg = 28) => pieza(g, new THREE.CylinderGeometry(rt, rb, h, seg), mat, x, y + h / 2, z);
  function patas(g, w, d, h, mat, inset = .06, r = .018) {
    [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([i, j]) => cil(g, r, r * .7, h, i * (w / 2 - inset), 0, j * (d / 2 - inset), mat, 12));
  }

  const CAT = {
    alfombra(g, S, o) { bx(g, o.w || 2.4, .014, o.d || 1.6, 0, .02, 0, S.alfombra, .006); },
    sofa(g, S, o) {
      const w = o.w || 2.2, d = .95;
      patas(g, w - .1, d - .1, .1, S.metal, .05, .015);
      bx(g, w, .2, d, 0, .1, 0, S.sofa, .04);
      bx(g, w, .44, .2, 0, .3, -d / 2 + .1, S.sofa, .06);
      [-1, 1].forEach(i => bx(g, .18, .32, d, i * (w / 2 - .09), .3, 0, S.sofa, .06));
      const n = 3, cw = (w - .4) / n;
      for (let k = 0; k < n; k++) {
        const cx = -w / 2 + .2 + cw / 2 + k * cw;
        bx(g, cw - .015, .14, d - .26, cx, .3, .06, S.sofa, .05);
        bx(g, cw - .03, .4, .16, cx, .42, -d / 2 + .28, S.sofa, .07);
      }
      bx(g, .42, .4, .12, -w / 2 + .45, .44, -d / 2 + .38, S.cojin1, .06).rotation.z = .12;
      bx(g, .4, .38, .12, w / 2 - .45, .44, -d / 2 + .38, S.cojin2, .06).rotation.z = -.1;
      bx(g, .6, .02, .5, w / 2 - .5, .45, .05, S.manta, .01);
    },
    mesaCentro(g, S) {
      cil(g, .42, .42, .035, 0, .36, 0, S.madera, 48);
      cil(g, .3, .3, .02, 0, .14, 0, S.madera, 48);
      [0, 1, 2].forEach(k => { const a = k * 2.094; cil(g, .014, .014, .38, Math.cos(a) * .3, 0, Math.sin(a) * .3, S.metal, 10); });
      cil(g, .06, .05, .12, .1, .395, -.05, MAT.porcelana, 24);
      bx(g, .22, .03, .16, -.12, .395, .08, S.lacado, .008);
    },
    muebleTV(g, S, o) {
      const w = o.w || 1.8;
      patas(g, w - .1, .38, .14, S.metal, .04, .012);
      bx(g, w, .42, .42, 0, .14, 0, S.madera, .015);
      for (let k = 0; k < 3; k++) bx(g, w / 3 - .02, .38, .01, -w / 3 + k * w / 3, .16, .21, S.frente, .004);
      bx(g, 1.23, .72, .035, 0, .6, -.08, MAT.pantalla, .01);
      bx(g, .3, .02, .18, 0, .56, -.05, S.metal, .005);
      cil(g, .06, .07, .16, w / 2 - .2, .56, 0, S.maceta, 20);
      pieza(g, new THREE.IcosahedronGeometry(.13, 1), MAT.hojas, w / 2 - .2, .82, 0);
    },
    lamparaPie(g, S) {
      cil(g, .14, .15, .025, 0, 0, 0, S.metal, 32);
      cil(g, .012, .012, 1.0, 0, .02, 0, S.metal, 10);
      cil(g, .14, .22, .26, 0, .86, 0, S.pantalla, 36);
      const l = new THREE.PointLight(0xffd9a6, 1.6, 3.2, 2); l.position.set(0, .9, 0); g.add(l);
    },
    planta(g, S, o) {
      const h = o.h || .9;
      cil(g, .16, .12, .3, 0, 0, 0, S.maceta, 28);
      cil(g, .145, .145, .02, 0, .28, 0, M({ color: 0x3b2a1e, roughness: 1 }), 20);
      // hojas grandes dibujadas (tipo ficus / costilla de Adán) sobre tarjetas curvas
      const H = hojaPlanta(), n = 10 + Math.round(h * 14);
      for (let k = 0; k < n; k++) {
        const t = k / n, a = k * 2.4, y = .35 + t * (h - .35), rr = .05 + Math.sin(t * Math.PI) * .18;
        const tallo = cil(g, .006, .006, Math.max(.05, y - .25), Math.cos(a) * rr * .3, .28, Math.sin(a) * rr * .3, MAT.hojas, 5);
        const m = new THREE.Mesh(H.geo, H.m); m.customDepthMaterial = H.d; m.castShadow = true; m.receiveShadow = true;
        m.position.set(Math.cos(a) * rr, y, Math.sin(a) * rr); m.rotation.order = 'YXZ'; m.rotation.y = -a + Math.PI / 2; m.rotation.x = -.5 - Math.random() * .6;
        const sc = (.22 + Math.random() * .1) * (0.8 + h * .25); m.scale.set(sc, sc, sc); g.add(m);
      }
    },
    comedor(g, S) {
      const w = 1.6, d = .9;
      bx(g, w, .04, d, 0, .72, 0, S.madera, .02);
      patas(g, w, d, .72, S.madera, .1, .025);
      [[-.45, -1], [.45, -1], [-.45, 1], [.45, 1]].forEach(([x, s]) => {
        const c = new THREE.Group(); c.position.set(x, 0, s * (d / 2 + .12)); c.rotation.y = s > 0 ? Math.PI : 0; g.add(c);
        patas(c, .42, .42, .45, S.madera, .03, .014);
        bx(c, .45, .045, .44, 0, .45, 0, S.madera, .02);
        bx(c, .45, .3, .03, 0, .5, -.21, S.madera, .015).rotation.x = -.08;
      });
      cil(g, .1, .08, .14, 0, .76, 0, MAT.porcelana, 24);
      pieza(g, new THREE.IcosahedronGeometry(.1, 1), MAT.hojas2, 0, .95, 0).scale.set(1.2, .6, 1.2);
    },
    aparador(g, S, o) {
      const w = o.w || 1.2;
      patas(g, w - .08, .38, .16, S.metal, .04, .012);
      bx(g, w, .62, .42, 0, .16, 0, S.madera, .015);
      for (let k = 0; k < 2; k++) bx(g, w / 2 - .02, .56, .01, -w / 4 + k * w / 2, .19, .21, S.frente, .004);
      cil(g, .07, .05, .3, -w / 3, .78, 0, MAT.porcelana, 24);
      bx(g, .3, .04, .22, w / 4, .78, 0, S.lacado, .01);
    },
    cocinaLineal(g, S, o) {
      const w = o.w || 3.6, d = .62, nev = .62, resto = w - nev;
      bx(g, resto, .1, d - .06, -nev / 2, 0, -.03, MAT.canto, 0);
      bx(g, resto, .76, d, -nev / 2, .1, 0, S.lacado, .006);
      const nP = Math.max(3, Math.round(resto / .6)), pw = resto / nP;
      for (let k = 0; k < nP; k++) {
        const x = -w / 2 + pw / 2 + k * pw;
        bx(g, pw - .012, .72, .02, x, .12, d / 2, S.frente, .006);
        bx(g, pw * .5, .012, .02, x, .78, d / 2 + .015, S.metal, .004);
      }
      bx(g, resto + .02, .04, d + .02, -nev / 2, .86, 0, S.encimera, .005);
      bx(g, .7, .012, .45, -w / 2 + resto * .62, .897, -.03, MAT.pantalla, .01);
      bx(g, .5, .02, .4, -w / 2 + resto * .28, .885, -.03, MAT.cromo, .02);
      cil(g, .012, .012, .28, -w / 2 + resto * .28, .9, -.24, MAT.cromo, 10);
      bx(g, nev, T - .06, d, w / 2 - nev / 2, 0, 0, S.frente, .008);
      bx(g, .02, .45, .02, w / 2 - nev + .06, .45, d / 2 + .01, S.metal, .005);
      bx(g, .4, .16, .3, -w / 2 + resto * .82, .9, -.1, MAT.porcelana, .02);
    },
    ducha(g, S, o) {
      const w = o.w || .9, d = o.d || 1.2;
      bx(g, w, .04, d, 0, .02, 0, MAT.porcelana, .01);
      bx(g, .01, .9, d * .7, w / 2, .06, d * .15, MAT.cristalDucha, 0).castShadow = false;
      cil(g, .1, .1, .01, -w / 2 + .15, .95, -d / 2 + .15, MAT.cromo, 24);
      cil(g, .01, .01, .9, -w / 2 + .05, .06, -d / 2 + .05, MAT.cromo, 8);
    },
    lavabo(g, S, o) {
      const w = o.w || .8;
      bx(g, w, .46, .46, 0, .38, 0, S.madera, .012);
      bx(g, w + .02, .03, .48, 0, .84, 0, S.encimera, .006);
      bx(g, w * .55, .12, .36, 0, .87, .02, MAT.porcelana, .05);
      cil(g, .012, .012, .18, 0, .87, -.2, MAT.cromo, 10);
      bx(g, w * .9, .26, .02, 0, .96, -.23, M({ color: 0xcfe3ea, metalness: .9, roughness: .05 }), .01);
    },
    inodoro(g) {
      bx(g, .38, .4, .55, 0, 0, .04, MAT.porcelana, .14);
      bx(g, .38, .03, .5, 0, .4, .06, MAT.porcelana, .05);
      bx(g, .4, .32, .16, 0, .38, -.2, MAT.porcelana, .05);
    },
    banera(g, S, o) {
      const w = o.w || 1.7, d = o.d || .8;
      bx(g, w, .55, d, 0, 0, 0, MAT.porcelana, .08);
      bx(g, w - .16, .02, d - .16, 0, .5, 0, MAT.agua, .05);
      [[-.4, .25], [.2, -.25], [.5, .2]].forEach(([x, z]) => cil(g, .02, .02, .01, x, .555, z, MAT.cromo, 16));
      cil(g, .015, .015, .2, w / 2 - .12, .55, -d / 2 + .08, MAT.cromo, 10);
      bx(g, .32, .1, .2, -w / 2 + .3, .56, 0, S.ropaCama, .04);
    },
    cama(g, S, o) {
      const w = o.w || 1.6, l = o.l || 2.0;
      bx(g, w + .06, .26, l, 0, .06, 0, S.madera, .03);
      patas(g, w, l, .06, S.madera, .08, .025);
      bx(g, w + .1, .95, .08, 0, .06, -l / 2 - .04, S.cabecero, .04);
      bx(g, w - .04, .22, l - .06, 0, .32, .01, S.ropaCama, .06);
      bx(g, w + .02, .07, l * .62, 0, .52, l * .19, S.ropaCama, .035);
      bx(g, w + .04, .03, .55, 0, .58, l / 2 - .32, S.manta, .015);
      const np = w > 1.3 ? 2 : 1;
      for (let k = 0; k < np; k++) {
        const x = np === 1 ? 0 : (k ? 1 : -1) * w / 4;
        bx(g, np === 1 ? w * .7 : w / 2 - .08, .14, .38, x, .54, -l / 2 + .28, S.ropaCama, .07).rotation.x = -.25;
      }
      bx(g, w * .35, .2, .1, 0, .58, -l / 2 + .42, S.cojin1, .05).rotation.x = -.3;
    },
    mesilla(g, S) {
      patas(g, .4, .36, .16, S.metal, .03, .01);
      bx(g, .42, .3, .38, 0, .16, 0, S.madera, .015);
      bx(g, .38, .12, .01, 0, .3, .19, S.frente, .004);
      cil(g, .07, .08, .02, 0, .46, 0, S.metal, 24);
      cil(g, .01, .01, .22, 0, .48, 0, S.metal, 8);
      cil(g, .08, .11, .14, 0, .66, 0, S.pantalla, 28);
    },
    escritorio(g, S, o) {
      const w = o.w || 1.1;
      bx(g, w, .03, .55, 0, .73, 0, S.madera, .01);
      patas(g, w, .55, .73, S.metal, .04, .012);
      bx(g, .5, .32, .015, .1, .78, -.2, MAT.pantalla, .008).rotation.x = -.15;
      cil(g, .06, .07, .1, -w / 2 + .14, .76, -.1, S.maceta, 20);
      pieza(g, new THREE.IcosahedronGeometry(.09, 1), MAT.hojas, -w / 2 + .14, .92, -.1);
      const s = new THREE.Group(); s.position.set(0, 0, .48); s.rotation.y = Math.PI; g.add(s);
      patas(s, .42, .42, .45, S.metal, .03, .012); bx(s, .45, .05, .44, 0, .45, 0, S.sofa, .02); bx(s, .45, .32, .04, 0, .52, -.2, S.sofa, .02);
    },
    armario(g, S, o) {
      const w = o.w || 2.0, h = Math.min(T, 2.3) - .05;
      bx(g, w, h, .6, 0, 0, 0, S.lacado, .008);
      const n = Math.round(w / .5), pw = w / n;
      for (let k = 0; k < n; k++) {
        const x = -w / 2 + pw / 2 + k * pw;
        bx(g, pw - .01, h - .04, .015, x, .02, .3, S.frente, .004);
        bx(g, .015, .35, .02, x + (k % 2 ? -1 : 1) * (pw / 2 - .05), h * .4, .31, S.metal, .004);
      }
    }
  };

  function hojaPlanta() {
    if (hojaPlanta.c) return hojaPlanta.c;
    const c = lienzo(256, (g, n) => {
      g.clearRect(0, 0, n, n); const gr = g.createLinearGradient(0, 0, n, 0); gr.addColorStop(0, '#2f5a2a'); gr.addColorStop(.5, '#4f8a3a'); gr.addColorStop(1, '#2d5527');
      g.fillStyle = gr; g.beginPath(); g.moveTo(n / 2, 6); g.bezierCurveTo(n * .98, n * .25, n * .9, n * .8, n / 2, n - 6); g.bezierCurveTo(n * .1, n * .8, n * .02, n * .25, n / 2, 6); g.fill();
      g.strokeStyle = 'rgba(190,220,150,.6)'; g.lineWidth = 3; g.beginPath(); g.moveTo(n / 2, 10); g.lineTo(n / 2, n - 8); g.stroke();
      g.lineWidth = 1.5; for (let i = 1; i < 8; i++) { const y = n * i / 9; [-1, 1].forEach(d => { g.beginPath(); g.moveTo(n / 2, y); g.quadraticCurveTo(n / 2 + d * n * .18, y - 8, n / 2 + d * n * .34, y - 20); g.stroke(); }); }
    });
    const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding;
    const geo = new THREE.PlaneGeometry(1, 1.25, 1, 4); geo.translate(0, .62, 0); const p = geo.attributes.position; for (let i = 0; i < p.count; i++) { const y = p.getY(i); p.setZ(i, -y * y * .35); } geo.computeVertexNormals();
    return (hojaPlanta.c = { geo, m: new THREE.MeshStandardMaterial({ map: t, alphaTest: .4, side: THREE.DoubleSide, roughness: .55, envMapIntensity: .6 }), d: new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map: t, alphaTest: .4 }) });
  }
  // ---------- Electrodomésticos, exterior y sanitario (añadidos para Calle Vinaroz 4) ----------
  const INOX = M({ color: 0xc9ccce, metalness: .85, roughness: .32, envMapIntensity: 1.3 });
  const CRISTAL_NEGRO = M({ color: 0x111214, metalness: .3, roughness: .08, envMapIntensity: 1.5 });
  const BLANCO_EL = M({ color: 0xf4f4f2, roughness: .3 });
  const TECA = madera(parquet(30, 45, 48), 1);
  const LONA = M({ map: tex(lienzo(256, (g, n) => { for (let i = 0; i < 8; i++) { g.fillStyle = i % 2 ? '#f3ede2' : '#c8b48c'; g.fillRect(i * n / 8, 0, n / 8, n); } }), 3, 1), roughness: 1, side: THREE.DoubleSide, transparent: true, opacity: .62, depthWrite: false });
  const VERDE_SAN = M({ color: 0x8fb3a6, roughness: .6 });
  Object.assign(CAT, {
    lavadora(g) {
      bx(g, .6, .85, .6, 0, 0, 0, BLANCO_EL, .03);
      cil(g, .2, .2, .03, 0, .42, .3, CRISTAL_NEGRO, 32).rotation.x = Math.PI / 2;
      cil(g, .23, .23, .02, 0, .42, .295, INOX, 32).rotation.x = Math.PI / 2;
      bx(g, .5, .08, .02, 0, .74, .3, CRISTAL_NEGRO, .01);
    },
    secadora(g) { CAT.lavadora(g); },
    lavadero(g, S, o) {
      const w = o.w || 1.6;
      bx(g, w, .86, .62, 0, 0, 0, S.lacado, .008);
      bx(g, w + .02, .04, .64, 0, .86, 0, S.encimera, .005);
      const l = new THREE.Group(); l.position.set(-w / 2 + .32, 0, .02); g.add(l); CAT.lavadora(l);
      const s = new THREE.Group(); s.position.set(-w / 2 + .94, 0, .02); g.add(s); CAT.lavadora(s);
      bx(g, .44, .1, .38, w / 2 - .3, .87, 0, MAT.porcelana, .04);
      cil(g, .01, .01, .2, w / 2 - .3, .9, -.24, MAT.cromo, 8);
    },
    frigorifico(g) {
      const FH = Math.min(T, 1.9) - .06; bx(g, .7, FH, .68, 0, 0, 0, INOX, .01);
      bx(g, .015, FH - .14, .02, -.3, .06, .35, CRISTAL_NEGRO, .004);
      bx(g, .69, .008, .02, 0, FH * .62, .345, CRISTAL_NEGRO, 0);
    },
    // Cocina completa: placa, horno, lavavajillas, fregadero, frigorífico combi, campana y microondas
    cocinaCompleta(g, S, o) {
      const w = o.w || 3.6, d = .62, nev = .7, resto = w - nev;
      bx(g, resto, .1, d - .06, -nev / 2, 0, -.03, MAT.canto, 0);
      bx(g, resto, .76, d, -nev / 2, .1, 0, S.lacado, .006);
      const nP = Math.max(3, Math.round(resto / .6)), pw = resto / nP;
      const xHorno = -w / 2 + resto * .62, xFreg = -w / 2 + resto * .26, xLava = xFreg + .6;
      for (let k = 0; k < nP; k++) {
        const x = -w / 2 + pw / 2 + k * pw;
        if (Math.abs(x - xHorno) < pw / 2 || Math.abs(x - xLava) < pw / 2) continue;
        bx(g, pw - .012, .72, .02, x, .12, d / 2, S.frente, .006);
        bx(g, pw * .5, .012, .02, x, .78, d / 2 + .015, S.metal, .004);
      }
      // horno bajo la placa
      bx(g, .58, .6, .02, xHorno, .16, d / 2 + .005, CRISTAL_NEGRO, .008);
      bx(g, .5, .02, .03, xHorno, .7, d / 2 + .02, INOX, .005);
      // lavavajillas integrado (panel con tirador inox y piloto)
      bx(g, .58, .72, .02, xLava, .12, d / 2 + .005, S.frente, .006);
      bx(g, .4, .014, .025, xLava, .76, d / 2 + .02, INOX, .004);
      bx(g, .03, .01, .01, xLava + .22, .2, d / 2 + .02, M({ color: 0x5fc5ff, emissive: 0x2a9fff, emissiveIntensity: 1 }), 0);
      bx(g, resto + .02, .04, d + .02, -nev / 2, .86, 0, S.encimera, .005);
      bx(g, .6, .012, .5, xHorno, .897, -.02, CRISTAL_NEGRO, .01);
      [[-.14, -.12], [.14, -.12], [-.14, .1], [.14, .1]].forEach(([a, b]) => cil(g, .07, .07, .002, xHorno + a, .904, -.02 + b, M({ color: 0x333333, roughness: .4 }), 24));
      bx(g, .52, .02, .4, xFreg, .885, -.03, MAT.cromo, .02);
      cil(g, .012, .012, .28, xFreg, .9, -.24, MAT.cromo, 10);
      // campana (estilizada a la altura de corte de la maqueta)
      const HC = Math.min(T, 1.75); bx(g, .7, .05, .48, xHorno, HC - .08, -.06, INOX, .01);
      bx(g, .22, T > 2 ? T - HC + .08 : .08, .2, xHorno, HC - .14 + (T > 2 ? .06 : 0), -.2, INOX, .01);
      // microondas y cafetera
      bx(g, .46, .27, .34, -w / 2 + resto * .9, .9, -.1, CRISTAL_NEGRO, .02);
      cil(g, .07, .07, .22, -w / 2 + resto * .08, .9, -.12, S.metal, 18);
      // frigorífico combi inox
      const f = new THREE.Group(); f.position.set(w / 2 - nev / 2, 0, -.03); g.add(f); CAT.frigorifico(f);
    },
    mesaExterior(g, S, o) {
      const n = (o && o.n) || 4, r = .5;
      cil(g, r, r, .035, 0, .72, 0, TECA, 40); cil(g, .04, .05, .72, 0, 0, 0, S.metal, 12); cil(g, .25, .28, .03, 0, 0, 0, S.metal, 24);
      for (let k = 0; k < n; k++) {
        const a = k / n * Math.PI * 2, c = new THREE.Group(); c.position.set(Math.sin(a) * (r + .32), 0, Math.cos(a) * (r + .32)); c.rotation.y = a + Math.PI; g.add(c);
        patas(c, .44, .44, .44, TECA, .03, .016); bx(c, .48, .04, .46, 0, .44, 0, TECA, .015); bx(c, .48, .32, .03, 0, .5, -.22, TECA, .012).rotation.x = -.12;
        bx(c, .4, .05, .38, 0, .48, .02, S.cojin2, .02);
      }
      cil(g, .09, .07, .14, 0, .755, 0, S.maceta, 20);
      pieza(g, new THREE.IcosahedronGeometry(.1, 1), MAT.hojas2, 0, .93, 0).scale.set(1.2, .7, 1.2);
    },
    jardinera(g, S, o) {
      const w = o.w || 1.6, d = .4;
      bx(g, w, .42, d, 0, 0, 0, M({ color: 0xd9d2c6, roughness: .85 }), .02);
      const n = Math.round(w / .22);
      for (let k = 0; k < n; k++) {
        const H = hojaPlanta(), px = -w / 2 + .12 + k * (w - .24) / Math.max(1, n - 1);
        for (let q = 0; q < 5; q++) { const m = new THREE.Mesh(H.geo, H.m); m.customDepthMaterial = H.d; m.castShadow = m.receiveShadow = true; m.position.set(px + (Math.random() - .5) * .1, .42, (Math.random() - .5) * .12); m.rotation.order = 'YXZ'; m.rotation.y = Math.random() * 6.28; m.rotation.x = -.3 - Math.random() * .7; m.scale.setScalar(.16 + Math.random() * .08); g.add(m); }
      }
      [-.3, .1, .45].forEach(f => cil(g, .025, .025, .02, f * w, .62, 0, M({ color: 0xf2c94c, roughness: .6 }), 8));
    },
    toldo(g, S, o) {
      const w = o.w || 4, d = o.d || 1.8, h = T - .03;
      const p = new THREE.Mesh(new THREE.PlaneGeometry(w, d * 1.03), LONA);
      p.position.set(0, h - .09, -.0); p.rotation.x = -Math.PI / 2 + .1; p.receiveShadow = true; p.castShadow = true; g.add(p);
      bx(g, w, .04, .05, 0, h - .2, d / 2, S.metal, .01);
      for (let k = 0; k < Math.round(w / .5); k++) bx(g, .02, .12, .01, -w / 2 + .25 + k * .5, h - .32, d / 2 + .03, LONA, 0);
    },
    // sanitario
    camilla(g, S) {
      patas(g, .6, 1.8, .62, INOX, .06, .02);
      bx(g, .66, .1, 1.9, 0, .62, 0, M({ color: 0x8fb3a6, roughness: .5 }), .03);
      bx(g, .6, .02, 1.7, 0, .72, .05, M({ color: 0xffffff, roughness: 1 }), .005);
      const r = bx(g, .62, .08, .5, 0, .74, -.7, M({ color: 0x8fb3a6, roughness: .5 }), .03); r.rotation.x = .3;
    },
    mostrador(g, S, o) {
      const w = o.w || 3;
      bx(g, w, 1.05, .45, 0, 0, .25, S.lacado, .01);
      bx(g, w + .06, .04, .5, 0, 1.05, .25, S.madera, .008);
      bx(g, w, .74, .7, 0, 0, -.35, S.madera, .008);
      [-.6, .6].forEach(x => { bx(g, .5, .32, .02, x * w / 3, .78, -.45, MAT.pantalla, .008).rotation.x = -.12; });
      const s = new THREE.Group(); s.position.set(0, 0, -.95); g.add(s); patas(s, .4, .4, .45, S.metal, .03, .012); bx(s, .45, .05, .44, 0, .45, 0, VERDE_SAN, .02);
    },
    sillasEspera(g, S, o) {
      const n = o.n || 4;
      bx(g, n * .55, .04, .06, 0, .38, -.05, S.metal, .01);
      for (let k = 0; k < n; k++) {
        const x = -n * .55 / 2 + .275 + k * .55;
        bx(g, .5, .06, .46, x, .42, 0, VERDE_SAN, .02); bx(g, .5, .38, .05, x, .48, -.22, VERDE_SAN, .02);
        cil(g, .015, .015, .4, x, 0, 0, S.metal, 8);
      }
    },
    escalera(g, S, o) {
      const w = o.w || 1.1, l = o.l || 2.6, n = 7, hp = (T - .05) / n;
      for (let k = 0; k < n; k++) bx(g, w, hp * (k + 1), l / n, -w / 2 - .02, 0, -l / 2 + l / n * (k + .5), MAT.piedra, .004);
      for (let k = 0; k < n; k++) bx(g, w, hp * (n - k), l / n, w / 2 + .02, 0, -l / 2 + l / n * (k + .5), MAT.piedra, .004);
      bx(g, .04, T - .1, l, 0, 0, 0, MAT.cristal, 0);
    },
    ascensor(g, S, o) {
      const w = o.w || 1.4, d = o.d || 1.6;
      bx(g, w, T - .05, d, 0, 0, 0, M({ color: 0xd8dadc, metalness: .5, roughness: .35 }), .01);
      bx(g, .9, T - .15, .02, 0, 0, d / 2 + .005, INOX, .004);
      bx(g, .01, T - .2, .025, 0, .02, d / 2 + .012, CRISTAL_NEGRO, 0);
    },
    coche(g, S, o) {
      const c = new THREE.Color(o.c || 0x9aa3ad), car = M({ color: c, metalness: .6, roughness: .3 });
      bx(g, 1.8, .55, 4.3, 0, .18, 0, car, .12);
      bx(g, 1.6, .42, 2.1, 0, .72, -.15, M({ color: 0x1d2228, metalness: .4, roughness: .1 }), .12);
      [[-.8, 1.35], [.8, 1.35], [-.8, -1.35], [.8, -1.35]].forEach(([x, z]) => { const w = cil(g, .32, .32, .22, x, .0, z, M({ color: 0x151515, roughness: .9 }), 20); w.rotation.z = Math.PI / 2; w.position.y = .32; });
    }
  });

  Object.assign(CAT, {
    isla(g, S, o) {
      const w = o.w || 2.4, d = .95;
      bx(g, w, .84, d, 0, 0, 0, S.frente, .01);
      bx(g, w + .1, .05, d + .1, 0, .84, 0, S.encimera, .008);
      [-1, 0, 1].forEach(k => {
        const s = new THREE.Group(); s.position.set(k * w / 3.2, 0, d / 2 + .32); g.add(s);
        cil(s, .17, .17, .05, 0, .7, 0, S.sofa, 24); cil(s, .02, .02, .7, 0, 0, 0, S.metal, 8); cil(s, .14, .16, .02, 0, 0, 0, S.metal, 20);
      });
      cil(g, .09, .07, .18, -w / 3, .89, -.1, MAT.porcelana, 24);
      pieza(g, new THREE.IcosahedronGeometry(.09, 1), MAT.hojas2, w / 3, .98, -.1);
    },
    piscina(g, S, o) {
      const w = o.w || 7, d = o.d || 2.4;
      bx(g, w + .4, .32, d + .4, 0, 0, 0, MAT.piedra, .02);
      bx(g, w, .03, d, 0, .3, 0, MAT.piscina, 0).castShadow = false;
      const l = new THREE.PointLight(0x5fe0ff, 3, 7, 2); l.position.set(0, .8, 0); g.add(l);
    },
    tumbona(g, S, o) {
      bx(g, .7, .26, 1.9, 0, .04, 0, S.madera, .03);
      patas(g, .66, 1.86, .05, S.madera, .05, .02);
      bx(g, .66, .09, 1.35, 0, .3, .26, S.ropaCama, .04);
      const r = bx(g, .66, .09, .62, 0, .4, -.62, S.ropaCama, .04); r.rotation.x = .55;
      bx(g, .4, .08, .26, 0, .55, -.66, S.cojin1, .04).rotation.x = .55;
    },
    sillon(g, S) {
      patas(g, .7, .7, .12, S.metal, .06, .014);
      bx(g, .8, .22, .8, 0, .12, 0, S.sofa, .06);
      bx(g, .8, .42, .16, 0, .3, -.32, S.sofa, .06);
      [-1, 1].forEach(i => bx(g, .14, .26, .8, i * .33, .3, 0, S.sofa, .06));
      bx(g, .36, .34, .1, 0, .42, -.18, S.cojin2, .05).rotation.x = -.2;
    }
  });

  // ---------- Casa ----------
  let techo = null, paseoOn = false;
  let casa = null, paredes = null, muebles = new THREE.Group(), capa = null, etiquetas = [], suelosMadera = [], D = null;
  let estiloActual = 'vacio', tPop = 0, t0 = null, viewTarget = 'maqueta';

  function disposeGroup(g) { g.traverse(o => { if (o.geometry) o.geometry.dispose(); if (o.material && o.material.map && o.material.__propio) { o.material.map.dispose(); o.material.dispose(); } }); }

  function caja(a, b, c, d, y0, h, mat, grupo, sombra = true) {
    const g = new THREE.BoxGeometry(Math.max((c - a) / PX, .1), h, Math.max((d - b) / PX, .1)); g.translate(0, h / 2, 0);
    const m = new THREE.Mesh(g, mat); m.position.set(X((a + c) / 2), y0, Z((b + d) / 2));
    m.castShadow = sombra; m.receiveShadow = true; grupo.add(m); return m;
  }

  function cargar(data) {
    D = data; PX = D.px || 100; T = D.alturaCorte || 1.15;
    if (casa) { scene.remove(casa); disposeGroup(casa); }
    casa = new THREE.Group(); scene.add(casa);
    paredes = new THREE.Group(); casa.add(paredes);
    muebles = new THREE.Group(); casa.add(muebles);
    suelosMadera = [];
    const all = D.paredes.concat(D.ventanas || [], D.barandillas || []);
    const xs = all.flatMap(p => [p[0], p[2]]), zs = all.flatMap(p => [p[1], p[3]]);
    const [x0, x1, z0, z1] = [Math.min(...xs), Math.max(...xs), Math.min(...zs), Math.max(...zs)];
    CX = (x0 + x1) / 2; CZ = (z0 + z1) / 2;
    const span = Math.max((x1 - x0), (z1 - z0)) / PX;
    const k = span / 12.5 * 1.22;
    VISTAS = { maqueta: [6.5 * k, 13 * k, 9 * k], aerea: [0, 17.5 * k, 0.01], baja: [9 * k, 3.6 * k, 7.5 * k] };
    ctr.maxDistance = 45 * Math.max(1, k);
    const sc = Math.max(14, span * .75); Object.assign(sun.shadow.camera, { left: -sc, right: sc, top: sc, bottom: -sc, far: sc * 5 }); sun.shadow.camera.updateProjectionMatrix();
    SOLD = Math.max(16, span * 1.3); hora(horaActual);

    const base = new THREE.Mesh(new RB((x1 - x0) / PX + .7, .28, (z1 - z0) / PX + .7, 2, .04), MAT.losa);
    base.position.set(0, -.15, 0); base.receiveShadow = true; casa.add(base);

    D.suelos.forEach(([a, b, c, d, t]) => {
      const w = (c - a) / PX + .1, dd = (d - b) / PX + .1;
      const src = { madera: SUELOS_ESTILO.vacio, baldosa: MAT.sueloBaldosa, gres: MAT.sueloGres, exterior: MAT.sueloExterior }[t];
      const rep = { madera: .45, baldosa: .75, gres: .9, exterior: .6 }[t];
      const m = M({ map: tex(src, w * rep, dd * rep), roughnessMap: tex(R_MADERA, w, dd, false), roughness: t === 'madera' ? .55 : .35 });
      m.__propio = true;
      const f = new THREE.Mesh(new THREE.BoxGeometry(w, .04, dd), m);
      f.position.set(X((a + c) / 2), 0, Z((b + d) / 2)); f.receiveShadow = true; casa.add(f);
      if (t === 'madera') suelosMadera.push({ m, w, dd });
    });
    D.paredes.forEach(w => { caja(...w, .02, T, MAT.pared, paredes); if (T < 2) caja(...w, T + .02, .022, MAT.canto, paredes); });
    // techo (solo visible en el paseo): deja entrar el sol únicamente por las ventanas
    techo = new THREE.Mesh(new THREE.BoxGeometry((x1 - x0) / PX, .12, (z1 - z0) / PX), M({ color: 0xf7f5f1, roughness: .9, emissive: 0xf3efe8, emissiveIntensity: .38 })); techo.position.set(0, T + .08, 0); techo.castShadow = true; techo.receiveShadow = true; techo.visible = paseoOn; casa.add(techo);
    (D.ventanas || []).forEach(v => {
      caja(...v, .02, .55, MAT.pared, paredes);
      const vh = T > 2 ? 1.6 : T - .55;
      caja(...v, .57, vh, MAT.cristal, paredes, false);
      if (T > 2) caja(...v, .57 + vh, T - .57 - vh, MAT.pared, paredes); else caja(...v, T + .02, .022, MAT.canto, paredes);
    });
    (D.barandillas || []).forEach(v => {
      caja(...v, .02, .08, MAT.canto, paredes);
      caja(...v, .1, .9, MAT.cristal, paredes, false);
    });

    if (capa) capa.remove();
    capa = document.createElement('div'); capa.className = 'm3-labels'; host.appendChild(capa);
    etiquetas = (D.etiquetas || []).map(([n, m2, x, y, on, id]) => {
      const e = document.createElement('div'); e.className = 'm3-lb' + (on ? ' on' : '') + (id ? ' clic' : '');
      e.innerHTML = `<b>${n}</b><span>${m2}</span>`; capa.appendChild(e);
      if (id) { e.dataset.id = id; e.style.pointerEvents = 'auto'; e.style.cursor = 'pointer'; e.addEventListener('click', () => window.P3D.onEtiqueta && window.P3D.onEtiqueta(id)); }
      return { e, v: new THREE.Vector3(X(x), T + .35, Z(y)) };
    });
    paredes.scale.y = .001; capa.style.opacity = 0; t0 = performance.now();
    estiloActual = 'vacio';
    size(); cam.position.set(...VISTAS.maqueta).multiplyScalar(factor()); ctr.target.set(0, 0, 0); ctr.autoRotate = true;
    cam.position.multiplyScalar(1.6);
    volar('maqueta', 1700);
  }

  function amueblar(estilo) {
    casa.remove(muebles); disposeGroup(muebles);
    muebles = new THREE.Group(); casa.add(muebles);
    estiloActual = estilo;
    const S = ESTILOS[estilo];
    MAT.pared.color.set(S ? S.pared : 0xf4efe8);
    suelosMadera.forEach(({ m, w, dd }) => {
      const t = tex(SUELOS_ESTILO[estilo] || SUELOS_ESTILO.vacio, w * (estilo === 'mediterraneo' ? .75 : .45), dd * (estilo === 'mediterraneo' ? .75 : .45));
      if (m.map) m.map.dispose(); m.map = t; m.needsUpdate = true;
    });
    if (!S) return;
    (D.muebles || []).forEach(([tipo, x, y, rot, o], i) => {
      if (!CAT[tipo]) return;
      const g = new THREE.Group();
      CAT[tipo](g, S, o || {});
      g.position.set(X(x), .02, Z(y)); g.rotation.y = (rot || 0) * Math.PI / 180;
      g.userData.retardo = i * 38; g.scale.setScalar(.001);
      muebles.add(g);
    });
    tPop = performance.now();
  }

  const ease = t => 1 - Math.pow(1 - Math.min(1, Math.max(0, t)), 3);
  const back = t => { t = Math.min(1, Math.max(0, t)); const c = 1.4; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); };

  function factor() { return host ? Math.max(1, 1.35 / (host.clientWidth / Math.max(1, host.clientHeight))) : 1; }
  function size() {
    if (!host || !host.clientWidth) return;
    renderer.setSize(host.clientWidth, host.clientHeight); cam.aspect = host.clientWidth / host.clientHeight; cam.updateProjectionMatrix();
  }
  function volar(v, ms = 1000) {
    viewTarget = v;
    const de = cam.position.clone(), a = new THREE.Vector3(...VISTAS[v]).multiplyScalar(factor()), s = performance.now(), t0 = ctr.target.clone(), t1 = new THREE.Vector3(0, 0, 0);
    (function mov() { const k = Math.min(1, (performance.now() - s) / ms); cam.position.lerpVectors(de, a, ease(k)); ctr.target.lerpVectors(t0, t1, ease(k)); if (k < 1) requestAnimationFrame(mov); })();
  }
  addEventListener('resize', size);

  const v = new THREE.Vector3();
  let activo = false;
  function loop(now) {
    requestAnimationFrame(loop);
    if (!activo || !casa) return;
    if (t0) {
      paredes.scale.y = Math.max(.001, ease((now - t0 - 500) / 1600));
      capa.style.opacity = Math.min(1, Math.max(0, (now - t0 - 1900) / 600));
    }
    if (tPop) muebles.children.forEach(g => g.scale.setScalar(Math.max(.001, back((now - tPop - g.userData.retardo) / 550))));
    ctr.update();
    renderer.render(scene, cam);
    const w = host.clientWidth, h = host.clientHeight;
    etiquetas.forEach(({ e, v: p }) => { v.copy(p).project(cam); e.style.transform = `translate(-50%,-100%) translate(${(v.x + 1) / 2 * w}px,${(1 - v.y) / 2 * h}px)`; });
  }
  requestAnimationFrame(loop);

  // Sol de verano en Oropesa (aprox. 40° N, julio). +z = fachada principal (calle).
  let SOLD = 16, horaActual = 18.5;
  function solVerano(h) {
    const ini = 6.75, fin = 21.45, t = Math.min(1, Math.max(0, (h - ini) / (fin - ini)));
    const elev = Math.max(2, 72 * Math.sin(Math.PI * t)) * Math.PI / 180;
    const az = (62 + t * 236) * Math.PI / 180;
    return { elev, dir: new THREE.Vector3(Math.sin(az) * Math.cos(elev), Math.sin(elev), -Math.cos(az) * Math.cos(elev)), t };
  }
  function hora(h) {
    const s = solVerano(h), e = s.elev / (72 * Math.PI / 180);
    horaActual = h; sun.position.copy(s.dir).multiplyScalar(SOLD);
    sun.color.setHSL(.09 - .03 * (1 - e), .55 + .4 * (1 - e), .82 - .12 * (1 - e));
    sun.intensity = 1.4 + 2.4 * Math.pow(e, .6);
    hemi.intensity = .35 + .35 * e;
    renderer.toneMappingExposure = .95 + .1 * e;
  }
  hora(18.5);

  // Paseo a la altura de los ojos: la cámara gira sobre sí misma mirando a un punto cercano.
  function camara(px, pz, alto, tx, tz, talto, ms = 1200) {
    const p1 = new THREE.Vector3(X(px), alto, Z(pz)), t1 = new THREE.Vector3(X(tx), talto, Z(tz));
    const p0 = cam.position.clone(), q0 = ctr.target.clone(), s = performance.now();
    (function mv() { const k = Math.min(1, (performance.now() - s) / ms), e = ease(k); cam.position.lerpVectors(p0, p1, e); ctr.target.lerpVectors(q0, t1, e); if (k < 1) requestAnimationFrame(mv); })();
  }
  function modoPaseo(b) {
    paseoOn = b; if (techo) techo.visible = b; ctr.autoRotate = false; scene.background = b ? new THREE.Color(0xc9dcea) : null;
    ctr.minDistance = b ? .05 : 3; ctr.maxPolarAngle = b ? Math.PI * .92 : Math.PI * .47; ctr.rotateSpeed = b ? -.35 : 1; ctr.enableZoom = !b;
    cam.fov = b ? 62 : 32; cam.updateProjectionMatrix(); if (capa) capa.style.visibility = b ? 'hidden' : 'visible';
  }

  window.P3D = {
    hora, solVerano, camara, modoPaseo, sombras(n) { sun.shadow.mapSize.set(n, n); if (sun.shadow.map) { sun.shadow.map.dispose(); sun.shadow.map = null; } },
    get T() { return T; },
    montar(el) { host = el; host.appendChild(renderer.domElement); renderer.domElement.addEventListener('pointerdown', () => { ctr.autoRotate = false; window.P3D.onStopGiro && window.P3D.onStopGiro(); }); size(); },
    cargar, amueblar, vista: v => volar(v), activar(b) { activo = b; if (b) size(); },
    girar(b) { ctr.autoRotate = b; }, resize: size, get estilo() { return estiloActual; },
    etiquetas(b) { if (capa) capa.style.visibility = b ? 'visible' : 'hidden'; }
  };
})();
